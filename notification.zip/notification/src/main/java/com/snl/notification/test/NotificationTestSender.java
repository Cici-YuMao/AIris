package com.snl.notification.test;

import com.snl.notification.entity.NotificationMessage;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
public class NotificationTestSender {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @PostMapping("/send")
    public String sendNotification(@RequestBody NotificationMessage msg) {
        rabbitTemplate.convertAndSend("notification.exchange", "notification.routingKey", msg);
        return "✅ Sent to MQ!";
    }
}

