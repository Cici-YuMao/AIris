package com.snl.notification.service;

import com.snl.notification.entity.Notification;
import com.snl.notification.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;


@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository repository;
    private final SimpMessagingTemplate messagingTemplate;



    public List<Notification> getUserNotifications(Long userId) {
        return repository.findByReceiverIdOrderByCreatedAtDesc(userId);
    }

    public void markAsRead(String id) {
        Notification n = repository.findById(id).orElseThrow();
        n.setStatus("read");
        repository.save(n);
    }
}
