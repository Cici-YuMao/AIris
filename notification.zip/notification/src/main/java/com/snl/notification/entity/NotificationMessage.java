package com.snl.notification.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;


//用于 MQ 传输的结构（输入结构）


@Data
public class NotificationMessage implements Serializable {
    private Long receiverId;
    private Long senderId;
    private String type;                // 通知类型，如 match/chat/media （必须三选一）
    private String title;               // 通知标题，用hc于UI展示。（匹配结果、审核结果、聊天消息、点赞～）
    private String content;             // 通知正文内容
    private Map<String, Object> metadata; // 扩展字段（如 matchId、mediaId、commentId、审核结果）
}
