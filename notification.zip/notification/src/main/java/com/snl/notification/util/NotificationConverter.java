package com.snl.notification.util;

import com.snl.notification.entity.Notification;
import com.snl.notification.entity.NotificationMessage;

import java.time.LocalDateTime;
import java.util.Map;

public class NotificationConverter {

    public static Notification fromMessage(NotificationMessage msg) {

        // message转成notification
        Notification n = new Notification();
        n.setReceiverId(msg.getReceiverId());
        n.setType(msg.getType());
        n.setTitle(msg.getTitle());
        n.setContent(msg.getContent());
        n.setStatus("unread"); // 默认未读
        n.setMetadata(msg.getMetadata() != null ? msg.getMetadata() : Map.of());
        n.setCreatedAt(LocalDateTime.now());

        return n;
    }
}

