//package com.snl.notification.config;
//
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.CorsRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//
//@Configuration
//public class WebCorsConfig implements WebMvcConfigurer {
//
//    @Override
//    public void addCorsMappings(CorsRegistry registry) {
//        registry.addMapping("/**") // 允许所有接口路径
//                .allowedOrigins(
//                        "http://localhost:5173",
//                        "http://10.144.1.1:5173", // 远程IP
//                        "http://10.144.1.1:3000"
//                )
//                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
//                .allowedHeaders("*")
//                .allowCredentials(true); // ✅ 如有携带 cookie，可开启
//    }
//}
