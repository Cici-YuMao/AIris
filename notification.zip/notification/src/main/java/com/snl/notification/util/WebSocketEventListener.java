package com.snl.notification.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

import java.util.List;
import java.util.Map;

@Component
public class WebSocketEventListener {

    @Autowired
    private OnlineUserManager onlineUserManager;

    @EventListener
    public void handleSessionConnected(SessionConnectEvent event) {
        StompHeaderAccessor headerAccessor = StompHeaderAccessor.wrap(event.getMessage());

        List<String> headers = headerAccessor.getNativeHeader("userId");
        String userId = (headers != null && !headers.isEmpty()) ? headers.get(0) : null;

        System.out.println("收到前端连接 header userId = " + userId); // 打印检查

        Map<String, Object> sessionAttributes = headerAccessor.getSessionAttributes();
        if (sessionAttributes != null && userId != null) {
            sessionAttributes.put("userId", userId);
            onlineUserManager.addUser(userId);
            System.out.println("🟢 用户上线：" + userId);
        } else {
            System.out.println("无法上线，header或session为空");
        }
    }

    @EventListener
    public void handleSessionDisconnect(SessionDisconnectEvent event) {
        StompHeaderAccessor headerAccessor = StompHeaderAccessor.wrap(event.getMessage());

        Map<String, Object> sessionAttributes = headerAccessor.getSessionAttributes();
        if (sessionAttributes != null) {
            String userId = (String) sessionAttributes.get("userId");

            if (userId != null) {
                onlineUserManager.removeUser(userId);
                System.out.println("🔴 用户下线：" + userId);
            } else {
                System.out.println("无法下线，session中无userId");
            }
        } else {
            System.out.println("无法下线，sessionAttributes为空");
        }
    }

}
