package com.snl.notification.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.Map;

@Data
@Document(collection = "notification_assets")
public class Notification {
    // spring默认就允许可为空

    @Id //默认由 MongoRepository 自动生成，不需要自己设置
    private String id;

    private Long receiverId;             // 接收通知的用户ID
    private Long senderId;               // 触发通知的用户ID（例如发消息/点赞人）

    private String type;                 // 通知类型，match/chat/media （必须三选一）
    private String title;                // 通知标题，用于UI展示。（匹配结果、审核结果、聊天消息、点赞～）
    private String content;              // 通知正文内容

    private String status;               // unread / read
    private String channel;              // push / email （如不在线，需要什么通知方式）
    private String emailNum;           // 具体联系号码/邮箱号

    private Map<String, Object> metadata;// 扩展字段（如 matchId、mediaId、commentId、审核结果）

    private LocalDateTime createdAt;     // 创建时间
}

