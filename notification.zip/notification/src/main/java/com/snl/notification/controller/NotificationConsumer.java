package com.snl.notification.controller;

import com.snl.notification.entity.Notification;
import com.snl.notification.entity.NotificationMessage;
import com.snl.notification.repository.NotificationRepository;
import com.snl.notification.service.EmailService;
import com.snl.notification.util.OnlineUserManager;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.Map;

@Component
public class NotificationConsumer {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private OnlineUserManager onlineUserManager;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @Autowired
    private EmailService emailService;

    private final RestTemplate restTemplate = new RestTemplate();

    @RabbitListener(queues = "notification.queue")
    public void receiveNotification(NotificationMessage msg) {
        System.out.println("消息队列已收到 MQ 通知：" + msg);
        Long receiverId = msg.getReceiverId();
        String receiverIdStr = String.valueOf(receiverId);

        // ==== Step 1: 查询用户设置 ====
        String url = "http://10.144.2.1:8081/internal-api/v1/users/" + receiverId + "/settings";
        boolean notificationEmail = false;
        boolean notificationPush = false;
        String email = null;

        try {
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                Map<String, Object> settingMap = response.getBody();
                System.out.println("用户设置：" + settingMap);

                notificationEmail = Boolean.parseBoolean(String.valueOf(settingMap.get("notificationEmail")));
                notificationPush = Boolean.parseBoolean(String.valueOf(settingMap.get("notificationPush")));
                email = (String) settingMap.get("email");
            } else {
                System.out.println("用户服务返回非 2xx：" + response.getStatusCode());
            }
        } catch (Exception e) {
            System.out.println("获取用户设置失败：" + e.getMessage());
        }

        // ==== Step 2: 构造 Notification ====
        Notification notification = new Notification();
        notification.setReceiverId(receiverId);
        notification.setSenderId(msg.getSenderId());
        notification.setType(msg.getType());
        notification.setTitle(msg.getTitle());
        notification.setContent(msg.getContent());
        notification.setStatus("unread");
        notification.setMetadata(msg.getMetadata() != null ? msg.getMetadata() : Map.of());
        notification.setCreatedAt(LocalDateTime.now());

        // 设置 channel
        StringBuilder channelBuilder = new StringBuilder();
        if (notificationEmail) channelBuilder.append("email");
        if (notificationPush) {
            if (channelBuilder.length() > 0) channelBuilder.append(" ");
            channelBuilder.append("push");
        }
        notification.setChannel(channelBuilder.toString());

        // 设置 emailNum
        notification.setEmailNum(email);

        // ==== Step 3: 存入 MongoDB ====
        notificationRepository.save(notification);

        // ==== Step 4: WebSocket 或 Email 推送 ====
        if (onlineUserManager.isOnline(receiverIdStr) && notificationPush) {
            messagingTemplate.convertAndSend("/topic/notifications/" + receiverIdStr, notification);
            System.out.println("✅ WebSocket 已推送至：" + receiverIdStr);
            if (notificationEmail && email != null) {
                String subject = "📢 New notifications\n\n";
                String body = "You have a new notification:\n\n" + msg.getTitle() + "\n\n" + msg.getContent();
                emailService.sendSimpleEmail(email, subject, body);
            }
        } else {
            System.out.println("用户不在线：" + receiverIdStr + "，通过 " + channelBuilder + " 通知");
            if (notificationEmail && email != null) {
                String subject = "📢 New notifications\n\n";
                String body = "You have a new notification:\n\n" + msg.getTitle() + "\n\n" + msg.getContent();
                emailService.sendSimpleEmail(email, subject, body);
            }
        }
    }
}
