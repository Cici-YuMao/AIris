package com.snl.notification.controller;

import com.snl.notification.entity.Notification;
import com.snl.notification.repository.NotificationRepository;
import com.snl.notification.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


// 处理网页前端的请求
@RestController
@RequestMapping("/notifications")
@RequiredArgsConstructor
public class NotificationController {


    private final NotificationService service;
    private final NotificationRepository repository;

    @GetMapping("/user/{userId}")
    public List<Notification> getUserNotifications(@PathVariable Long userId) {
        return service.getUserNotifications(userId);
    }

    @PutMapping("/{id}/read")
    public void markAsRead(@PathVariable String id) {
        service.markAsRead(id);
    }

    // 删除图片
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteById(@PathVariable String id) {
        repository.deleteById(id);
        return ResponseEntity.ok("Deleted notification with ID: " + id);
    }
}
