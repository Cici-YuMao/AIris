package com.snl.notification;

import com.snl.notification.service.EmailService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsDemoApplicationTests {

    @Autowired
    private EmailService emailService;

    @Test
    void contextLoads() {
    }

    @Test
    void testSendEmail() {
        String to = "snl.lee02@gmail.com"; // test: receiverID
        String subject = "📢 测试通知";
        String body = "这是来自测试方法的通知邮件，说明邮件服务正常工作。";

        emailService.sendSimpleEmail(to, subject, body);
        System.out.println("✅ 测试邮件已发送至：" + to);
    }
}

