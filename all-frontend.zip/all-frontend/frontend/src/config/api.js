
export const GATEWAY_URL = 'http://10.144.2.1:8088';

export const NOTIFICATION_SERVICE_URL = 'http://10.144.122.245:8082';
export const MEDIA_SERVICE_URL = 'http://10.144.122.245:8081';

