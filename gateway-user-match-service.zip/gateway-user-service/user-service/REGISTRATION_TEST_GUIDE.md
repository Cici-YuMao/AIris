# 📧 注册流程测试指南

## 🎯 当前配置

✅ **保留邮箱验证码** - 确保邮箱真实性
✅ **去掉激活邮件** - 注册后直接可用
✅ **账户直接激活** - 无需点击激活链接

## 🔧 解决验证码获取问题

由于邮件服务配置问题，我们需要通过其他方式获取验证码。

### 方案一：查看应用日志（推荐）

验证码会在控制台日志中显示，启动应用后查看日志：

```bash
# 启动应用并查看日志
mvn spring-boot:run

# 发送验证码后，在日志中查找类似这样的信息：
# Your verification code is: 123456, valid for 5 minutes.
```

### 方案二：添加开发环境接口

我之前为您添加了开发环境专用接口，重启应用后可以使用：

```bash
# 1. 设置固定验证码
curl -X POST http://localhost:8081/api/v1/auth/dev/set-fixed-code \
-H "Content-Type: application/json" \
-d '{"email": "test@example.com", "code": "123456"}'

# 2. 获取验证码
curl "http://localhost:8081/api/v1/auth/dev/get-verification-code?email=test@example.com"
```

## 🧪 完整测试流程

### 步骤1：发送验证码

```bash
curl -X POST http://localhost:8081/api/v1/auth/send-email-code \
-H "Content-Type: application/json" \
-d '{"email": "test@example.com"}'
```

### 步骤2：查看验证码

**方法A：查看应用日志**
在控制台中找到验证码信息

**方法B：使用开发接口**
```bash
curl "http://localhost:8081/api/v1/auth/dev/get-verification-code?email=test@example.com"
```

### 步骤3：注册用户

```bash
curl -X POST http://localhost:8081/api/v1/auth/register \
-H "Content-Type: application/json" \
-d '{
  "username": "testuser",
  "email": "test@example.com",
  "password": "123456",
  "verificationCode": "这里填入获取到的验证码"
}'
```

### 步骤4：直接登录

```bash
curl -X POST http://localhost:8081/api/v1/auth/login \
-H "Content-Type: application/json" \
-d '{
  "identifier": "testuser",
  "password": "123456"
}'
```

## 🎨 前端实现示例

```jsx
import React, { useState } from 'react';
import axios from 'axios';

const Register = () => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    verificationCode: ''
  });
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // 发送验证码
  const sendVerificationCode = async () => {
    if (!formData.email) {
      setMessage('请先输入邮箱');
      return;
    }

    try {
      setIsLoading(true);
      await axios.post('/api/v1/auth/send-email-code', {
        email: formData.email
      });

      setMessage('验证码已发送，请查看控制台日志获取验证码');

      // 开发环境：尝试自动获取验证码
      if (process.env.NODE_ENV === 'development') {
        setTimeout(async () => {
          try {
            const response = await axios.get(`/api/v1/auth/dev/get-verification-code?email=${formData.email}`);
            if (response.data.verificationCode) {
              setFormData(prev => ({
                ...prev,
                verificationCode: response.data.verificationCode
              }));
              setMessage(`验证码已自动填入: ${response.data.verificationCode}`);
            }
          } catch (error) {
            console.log('自动获取验证码失败，请手动查看日志');
          }
        }, 1000);
      }

    } catch (error) {
      setMessage('验证码发送失败: ' + (error.response?.data || error.message));
    } finally {
      setIsLoading(false);
    }
  };

  // 注册
  const handleRegister = async (e) => {
    e.preventDefault();

    try {
      setIsLoading(true);
      const response = await axios.post('/api/v1/auth/register', formData);
      setMessage('注册成功！可以直接登录使用');

      // 可以自动跳转到登录页面或主页
      // navigate('/login');

    } catch (error) {
      setMessage('注册失败: ' + (error.response?.data || error.message));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="register-container">
      <h2>用户注册</h2>

      <form onSubmit={handleRegister}>
        <div className="form-group">
          <label>用户名</label>
          <input
            type="text"
            value={formData.username}
            onChange={(e) => setFormData({...formData, username: e.target.value})}
            required
            minLength={3}
            maxLength={50}
          />
        </div>

        <div className="form-group">
          <label>邮箱</label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            required
          />
        </div>

        <div className="form-group">
          <label>密码</label>
          <input
            type="password"
            value={formData.password}
            onChange={(e) => setFormData({...formData, password: e.target.value})}
            required
            minLength={6}
            maxLength={20}
          />
        </div>

        <div className="form-group">
          <label>验证码</label>
          <div className="verification-input">
            <input
              type="text"
              value={formData.verificationCode}
              onChange={(e) => setFormData({...formData, verificationCode: e.target.value})}
              required
              placeholder="请输入6位验证码"
            />
            <button
              type="button"
              onClick={sendVerificationCode}
              disabled={!formData.email || isLoading}
            >
              {isLoading ? '发送中...' : '获取验证码'}
            </button>
          </div>
        </div>

        <button type="submit" disabled={isLoading}>
          {isLoading ? '注册中...' : '注册'}
        </button>
      </form>

      {message && (
        <div className={`message ${message.includes('成功') ? 'success' : 'error'}`}>
          {message}
        </div>
      )}

      {/* 开发提示 */}
      {process.env.NODE_ENV === 'development' && (
        <div className="dev-tips">
          <h4>开发提示：</h4>
          <p>1. 点击"获取验证码"后查看控制台日志</p>
          <p>2. 或者验证码会自动填入输入框</p>
          <p>3. 注册成功后无需邮箱激活，直接可以登录</p>
        </div>
      )}
    </div>
  );
};

export default Register;
```

## 📋 验证清单

- [ ] 邮箱验证码正常发送
- [ ] 能够获取到验证码（通过日志或开发接口）
- [ ] 使用正确验证码可以注册成功
- [ ] 注册后账户状态为 ACTIVE
- [ ] 可以直接登录，无需激活
- [ ] 错误处理正常工作

## 🚨 常见问题

### Q: 验证码获取不到怎么办？
A: 查看应用启动日志，验证码会在控制台中显示

### Q: 注册时提示验证码错误？
A: 确保验证码在5分钟有效期内，且输入正确

### Q: 注册成功但无法登录？
A: 检查用户名和密码是否正确，账户状态应该是 ACTIVE

这样您就可以保留邮箱验证的安全性，同时简化注册流程了！

