package com.airis.user.controller;

import com.airis.user.dto.*;
import com.airis.user.service.UserPreferenceService;
import com.airis.user.service.UserService;
import com.airis.user.service.UserSettingsService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    private final UserService userService;
    private final UserSettingsService userSettingsService;
    private final UserPreferenceService userPreferenceService;

    public UserController(UserService userService,
                          UserSettingsService userSettingsService,
                          UserPreferenceService userPreferenceService) {
        this.userService = userService;
        this.userSettingsService = userSettingsService;
        this.userPreferenceService = userPreferenceService;
    }

    /**
     * 获取当前用户信息
     */
    @GetMapping("/me")
    public ResponseEntity<UserInfoResponse> getCurrentUser(Authentication authentication) {
        Long userId = (Long) authentication.getPrincipal();
        UserInfoResponse userInfo = userService.getUserInfo(userId);
        return ResponseEntity.ok(userInfo);
    }

    /**
     * 修改当前用户信息
     */
    @PutMapping("/me")
    public ResponseEntity<?> updateCurrentUser(@RequestBody @Valid UserUpdateRequest request, Authentication authentication) {
        System.out.println("authentication.getPrincipal()=" + authentication.getPrincipal());
        Long userId = (Long) authentication.getPrincipal();
        userService.updateUserInfo(userId, request);
        return ResponseEntity.ok("修改成功");
    }

    /**
     * 获取当前用户设置
     */
    @GetMapping("/settings")
    public ResponseEntity<UserSettingsResponse> getUserSettings(Authentication authentication) {
        System.out.println("=== getUserSettings called ===");
        System.out.println("Authentication: " + authentication);
        System.out.println("Principal: " + authentication.getPrincipal());

        Long userId = (Long) authentication.getPrincipal();
        System.out.println("User ID: " + userId);

        UserSettingsResponse resp = userSettingsService.getUserSettings(userId);
        System.out.println("Settings response: " + resp);

        return ResponseEntity.ok(resp);
    }

    /**
     * 删除当前用户
     * @param authentication
     * @return
     */
    @DeleteMapping("/me")
    public ResponseEntity<?> deleteCurrentUser(Authentication authentication) {
        Object principal = authentication.getPrincipal();
        Long userId = principal instanceof Long ? (Long) principal : Long.valueOf(principal.toString());
        userService.deleteUser(userId);
        return ResponseEntity.ok("账号已注销");
    }


    /**
     * 修改当前用户设置
     */
    @PutMapping("/settings")
    public ResponseEntity<?> updateUserSettings(@RequestBody @Valid UserSettingsUpdateRequest request, Authentication authentication) {
        Long userId = (Long) authentication.getPrincipal();
        userSettingsService.updateUserSettings(userId, request);
        return ResponseEntity.ok("设置修改成功");
    }

    /**
     * 获取当前用户偏好
     */
    @GetMapping("/preference")
    public ResponseEntity<UserPreferenceResponse> getUserPreference(Authentication authentication) {
        Long userId = (Long) authentication.getPrincipal();
        UserPreferenceResponse resp = userPreferenceService.getUserPreference(userId);
        return ResponseEntity.ok(resp);
    }

    /**
     * 修改当前用户偏好
     */
    @PutMapping("/preference")
    public ResponseEntity<?> updateUserPreference(@RequestBody @Valid UserPreferenceUpdateRequest request, Authentication authentication) {
        Long userId = (Long) authentication.getPrincipal();
        userPreferenceService.updateUserPreference(userId, request);
        return ResponseEntity.ok("偏好设置修改成功");
    }

    /**
     * 根据id获取用户名
     * @param id
     * @return
     */
    @GetMapping("/{id}/username")
    public ResponseEntity<?> getUsernameById(@PathVariable Long id) {
        String username = userService.getUsernameById(id);
        return ResponseEntity.ok(new UsernameResponse(id, username));
    }
}
