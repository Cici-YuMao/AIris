package com.airis.user.service;

import com.airis.user.dto.LoginRequest;
import com.airis.user.dto.LoginResponse;
import com.airis.user.dto.RefreshTokenResponse;
import com.airis.user.dto.RegisterRequest;

public interface AuthService {
    void register(RegisterRequest request);
    LoginResponse login(LoginRequest request);
    void sendEmailVerificationCode(String email);
    RefreshTokenResponse refreshToken(String refreshToken);
    void logout(String authHeader);
    void activateAccount(String code);
    void sendResetPasswordEmail(String email);
    void resetPassword(String code, String newPassword);

}
