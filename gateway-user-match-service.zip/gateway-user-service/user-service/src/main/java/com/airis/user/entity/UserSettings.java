package com.airis.user.entity;

import lombok.Data;
import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "user_settings")
public class UserSettings {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    private Boolean notificationEmail = true;
    private Boolean notificationPush = true;
    private Boolean notificationSms = false;

    @Column(length = 20)
    private String privacyLevel = "PUBLIC";

    private Boolean displayOnlineStatus = true;
    private Boolean displayLastActive = true;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
}
