package com.airis.user.repository;

import com.airis.user.entity.UserComment;
import io.lettuce.core.dynamic.annotation.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface UserCommentRepository extends JpaRepository<UserComment, Long> {
    // 统计某个用户收到的评论数
    @Query("SELECT COUNT(uc) FROM UserComment uc WHERE uc.commentedUserId = :userId")
    Long countByCommentedUserId(@Param("userId") Long userId);
}

