package com.airis.user.service.impl;

import com.airis.user.dto.*;
import com.airis.user.entity.User;
import com.airis.user.entity.UserPreference;
import com.airis.user.entity.UserSettings;
import com.airis.user.repository.UserPreferenceRepository;
import com.airis.user.repository.UserRepository;
import com.airis.user.repository.UserSettingsRepository;
import com.airis.user.service.AlgorithmPushService;
import com.airis.user.service.AuthService;
import com.airis.user.util.JwtUtil;
import io.lettuce.core.RedisException;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @Value("${project.activation-url-prefix}")
    private String activationUrlPrefix;

    @Autowired
    private UserSettingsRepository userSettingsRepository;

    @Autowired
    private UserPreferenceRepository userPreferenceRepository;

    @Value("${register.limit.count:3}")
    private int registerLimitCount;

    @Autowired
    private AlgorithmPushService algorithmPushService;

    @Value("${project.reset-password-url-prefix}")
    private String resetPasswordUrlPrefix;


    @Override
    public void register(RegisterRequest request) {
        // 1. 校验邮箱验证码
        String redisKey = "email:verify:" + request.getEmail();
        String codeInRedis = redisTemplate.opsForValue().get(redisKey);
        if (codeInRedis == null || !codeInRedis.equals(request.getVerificationCode())) {
            throw new RuntimeException("Verification code is incorrect or expired");
        }

        // 2. IP限流
        String ip = getClientIp(httpServletRequest);
        String ipRedisKey = "register:ip:" + ip;
        Long count;
        try {
            count = redisTemplate.opsForValue().increment(ipRedisKey);
            if (count == 1) {
                redisTemplate.expire(ipRedisKey, 1, TimeUnit.MINUTES);
            }
        } catch (RedisException e) {
            log.error("Redis operation exception", e);
            throw new ServiceException("System busy, please try again later");
        }
        if (count > registerLimitCount) {
            throw new RuntimeException("Registration too frequent, please try again later");
        }


        // 3. 检查邮箱或用户名是否已注册
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("Email already registered");
        }
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            throw new RuntimeException("Username already registered");
        }

        // 4. 密码加密
        String encodedPassword = passwordEncoder.encode(request.getPassword());

        // 5. 构建User对象（赋值所有详细个人信息字段）
        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        user.setPasswordHash(encodedPassword);
        user.setAccountStatus("ACTIVE");
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        // 新增详细个人信息字段赋值
        user.setName(request.getName());
        user.setGender(request.getGender());
        user.setAge(request.getAge());
        user.setSexualOrientation(request.getSexualOrientation());
        user.setHeight(request.getHeight());
        user.setWeight(request.getWeight());
        user.setCity(request.getCity());
        user.setEducation(request.getEducation());
        user.setOccupation(request.getOccupation());
        user.setHobbies(request.getHobbies());
        user.setPets(request.getPets());
        user.setFamilyStatus(request.getFamilyStatus());
        // 自动获取IP
        user.setIpAddress(ip);

        // 6. 保存到数据库
        userRepository.save(user);

        // 用户设置
        UserSettings settings = new UserSettings();
        settings.setUserId(user.getId());
        if (request.getSettings() != null) {
            UserSettingsUpdateRequest reqSettings = request.getSettings();
            if (reqSettings.getNotificationEmail() != null) settings.setNotificationEmail(reqSettings.getNotificationEmail());
            if (reqSettings.getNotificationPush() != null) settings.setNotificationPush(reqSettings.getNotificationPush());
            if (reqSettings.getNotificationSms() != null) settings.setNotificationSms(reqSettings.getNotificationSms());
            if (reqSettings.getPrivacyLevel() != null) settings.setPrivacyLevel(reqSettings.getPrivacyLevel());
            if (reqSettings.getDisplayOnlineStatus() != null) settings.setDisplayOnlineStatus(reqSettings.getDisplayOnlineStatus());
            if (reqSettings.getDisplayLastActive() != null) settings.setDisplayLastActive(reqSettings.getDisplayLastActive());
        } else {
            // 默认值
            settings.setNotificationEmail(true);
            settings.setNotificationPush(true);
            settings.setNotificationSms(false);
            settings.setPrivacyLevel("PUBLIC");
            settings.setDisplayOnlineStatus(true);
            settings.setDisplayLastActive(true);
        }
        settings.setCreatedAt(LocalDateTime.now());
        settings.setUpdatedAt(LocalDateTime.now());
        userSettingsRepository.save(settings);

        // 用户偏好（最新结构）
        UserPreference preference = new UserPreference();
        preference.setUserId(user.getId());
        if (request.getPreference() != null) {
            UserPreferenceUpdateRequest reqPreference = request.getPreference();
            if (reqPreference.getAgeRange() != null) preference.setAgeRange(reqPreference.getAgeRange());
            if (reqPreference.getHeightRange() != null) preference.setHeightRange(reqPreference.getHeightRange());
            if (reqPreference.getWeightRange() != null) preference.setWeightRange(reqPreference.getWeightRange());
            if (reqPreference.getSexualOrientation() != null) preference.setSexualOrientation(reqPreference.getSexualOrientation());
            if (reqPreference.getPreferredEducation() != null) preference.setPreferredEducation(reqPreference.getPreferredEducation());
            if (reqPreference.getPreferredOccupation() != null) preference.setPreferredOccupation(reqPreference.getPreferredOccupation());
            if (reqPreference.getPreferredCities() != null) preference.setPreferredCities(reqPreference.getPreferredCities());
            if (reqPreference.getHobbies() != null) preference.setHobbies(reqPreference.getHobbies());
            if (reqPreference.getDealBreakers() != null) preference.setDealBreakers(reqPreference.getDealBreakers());
            if (reqPreference.getTopPriorities() != null) preference.setTopPriorities(reqPreference.getTopPriorities());
        }
        preference.setCreatedAt(new Date());
        preference.setUpdatedAt(new Date());
        userPreferenceRepository.save(preference);

        // 7. 注册成功，账户直接激活（跳过邮件激活步骤）
        log.info("用户注册成功，账户已激活: {}", user.getEmail());

        // 注册后异步推送算法服务（operation: update）- 不影响注册流程
        try {
            algorithmPushService.pushUserData(user.getId(), "update");
        } catch (Exception e) {
            log.warn("推送算法服务失败，但不影响用户注册，用户ID: {}, 错误: {}", user.getId(), e.getMessage());
        }

    }

    @Override
    public LoginResponse login(LoginRequest request) {


        // 1. 查询用户（用户名或邮箱）
        User user = userRepository.findByUsername(request.getIdentifier())
                .orElseGet(() -> userRepository.findByEmail(request.getIdentifier()).orElse(null));
        if (user == null) {
            throw new RuntimeException("User does not exist.");
        }

        // 2. 登录风控（账号锁定）
        String loginFailKey = "login:fail:" + user.getId();
        String accountLockKey = "account:lock:" + user.getId();

        if (redisTemplate.hasKey(accountLockKey)) {
            throw new RuntimeException("Your account has been locked. Please try again after 30 minutes.");
        }

        // 3. 校验密码
        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            Long failCount = redisTemplate.opsForValue().increment(loginFailKey);
            if (failCount == 1) {
                redisTemplate.expire(loginFailKey, 5, TimeUnit.MINUTES);
            }
            if (failCount >= 5) {
                redisTemplate.opsForValue().set(accountLockKey, "LOCKED", 30, TimeUnit.MINUTES);
            }
            throw new RuntimeException("Password error, 5 consecutive failures will lock the account");
        } else {
            // 登录成功，清除失败记录
            redisTemplate.delete(loginFailKey);
        }

        // 4. 检查账号状态
        if (!"ACTIVE".equals(user.getAccountStatus())) {
            throw new RuntimeException("The account is unavailable or has been locked.");
        }

        // 5. 生成JWT
        String accessToken = jwtUtil.generateAccessToken(user.getId(), user.getUsername());
        String refreshToken = jwtUtil.generateRefreshToken(user.getId());

//        System.out.println("生成新的accessToken: " + accessToken);


        // 6. 返回响应
        return new LoginResponse(
                accessToken,
                refreshToken,
                user.getId(),
                user.getUsername(),
                user.getEmail()
        );
    }

    @Override
    public void sendEmailVerificationCode(String email) {
        // 1. 生成6位验证码
        String code = String.valueOf((int)((Math.random() * 9 + 1) * 100000));

        // 2. 存入Redis，5分钟有效
        String redisKey = "email:verify:" + email;
        redisTemplate.opsForValue().set(redisKey, code, 5, TimeUnit.MINUTES);

        // 3. 在日志中显示验证码（开发调试用）
        log.info("=== 验证码发送 ===");
        log.info("邮箱: {}", email);
        log.info("验证码: {}", code);
        log.info("有效期: 5分钟");
        log.info("==================");

        // 4. 尝试发送邮件
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(email);
            message.setSubject("AIris Registration Verification Code");
            message.setText("Your verification code is: " + code + ", valid for 5 minutes.");
            mailSender.send(message);
            log.info("验证码邮件发送成功: {}", email);
        } catch (Exception e) {
            log.warn("邮件发送失败，但验证码已生成: {}, 错误: {}", email, e.getMessage());
            // 不抛出异常，因为验证码已经生成并在日志中显示
        }
    }

    @Override
    public RefreshTokenResponse refreshToken(String refreshToken) {
        // 校验refresh token有效性
        Long userId;
        try {
            userId = jwtUtil.parseUserId(refreshToken);
        } catch (Exception e) {
            throw new RuntimeException("The refresh token is invalid or expired");
        }
        // 生成新的access token和refresh token
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User does not exist"));
        String newAccessToken = jwtUtil.generateAccessToken(user.getId(), user.getUsername());
        String newRefreshToken = jwtUtil.generateRefreshToken(user.getId());
        return new RefreshTokenResponse(newAccessToken, newRefreshToken);
    }

    @Override
    public void logout(String authHeader) {
        // 解析token
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new RuntimeException("No valid token");
        }
        String token = authHeader.replace("Bearer ", "");
        // 解析token剩余有效期
        Date expireDate = jwtUtil.getExpiration(token);
        long ttl = (expireDate.getTime() - System.currentTimeMillis()) / 1000;
        if (ttl > 0) {
            // 加入黑名单
            redisTemplate.opsForValue().set("jwt:blacklist:" + token, "1", ttl, TimeUnit.SECONDS);
        }
    }

    @Override
    public void activateAccount(String code) {
        String activationKey = "user:activate:" + code;
        String email = redisTemplate.opsForValue().get(activationKey);
        if (email == null) {
            throw new RuntimeException("Activation code is invalid or expired");
        }
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User does not exist"));
        user.setAccountStatus("ACTIVE");
        userRepository.save(user);
        redisTemplate.delete(activationKey);
    }

    @Override
    public void sendResetPasswordEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Email not found"));

        String resetCode = UUID.randomUUID().toString();
        String resetKey = "user:reset:" + resetCode;
        redisTemplate.opsForValue().set(resetKey, email, 30, TimeUnit.MINUTES);

        String resetUrl = resetPasswordUrlPrefix + "/api/v1/auth/reset-password?code=" + resetCode;
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("AIris Password Reset");
        message.setText("Please click the following link to reset your password (valid within 30 minutes):\n" + resetUrl);
        mailSender.send(message);
    }

    @Override
    public void resetPassword(String code, String newPassword) {
        String resetKey = "user:reset:" + code;
        String email = redisTemplate.opsForValue().get(resetKey);
        if (email == null) {
            throw new RuntimeException("Reset code is invalid or expired");
        }
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User does not exist"));
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        userRepository.save(user);
        redisTemplate.delete(resetKey);
    }

    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (StringUtils.isEmpty(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (StringUtils.isEmpty(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

}
