package com.airis.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class MatchServiceClient {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${match.service.url:http://localhost:8082}")
    private String matchServiceUrl;

    /**
     * 清空用户匹配缓存
     */
    public void clearUserMatchCache(Long userId) {
        try {
            String url = matchServiceUrl + "/api/v1/match/internal/clear-cache/" + userId;
            restTemplate.postForObject(url, null, Void.class);
            System.out.println("成功调用匹配服务清理缓存，用户ID: " + userId);
        } catch (Exception e) {
            System.err.println("调用匹配服务清理缓存失败，用户ID: " + userId + ", 错误: " + e.getMessage());
        }
    }
}

