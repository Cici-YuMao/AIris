package com.airis.user.controller;

import com.airis.user.dto.CommentResponse;
import com.airis.user.service.UserInteractionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/internal-api/v1/users")
public class InternalUserController {

    @Autowired
    private UserInteractionService userInteractionService;

    /**
     * 获取用户互动数据（供匹配服务调用）
     */
    @GetMapping("/{userId}/interaction-data")
    public Map<String, Object> getUserInteractionData(@PathVariable Long userId) {
        Map<String, Object> result = new HashMap<>();

        try {
            int likeCount = userInteractionService.getLikeCount(userId);
            int commentCount = userInteractionService.getCommentCount(userId);
            List<CommentResponse> comments = userInteractionService.getReceivedComments(userId);

            result.put("likeCount", likeCount);
            result.put("commentCount", commentCount);
            result.put("comments", comments);
        } catch (Exception e) {
            result.put("likeCount", 0);
            result.put("commentCount", 0);
            result.put("comments", Collections.emptyList());
        }

        return result;
    }
}

