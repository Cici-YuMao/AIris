package com.airis.user.controller;

import com.airis.user.dto.*;
import com.airis.user.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/v1/auth")
@Validated
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody @Valid RegisterRequest request) {
        try {
            authService.register(request);
            return ResponseEntity.ok("注册成功，可以直接登录使用");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("注册失败: " + e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody @Valid LoginRequest request) {
        LoginResponse response = authService.login(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/send-email-code")
    public ResponseEntity<?> sendEmailVerificationCode(@RequestBody @Valid SendVerificationCodeRequest request) {
        authService.sendEmailVerificationCode(request.getEmail());
        return ResponseEntity.ok("The verification code has been sent, please check your email");
    }

    @PostMapping("/refresh-token")
    public ResponseEntity<RefreshTokenResponse> refreshToken(@RequestBody @Valid RefreshTokenRequest request) {
        RefreshTokenResponse response = authService.refreshToken(request.getRefreshToken());
        return ResponseEntity.ok(response);
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestHeader("Authorization") String authHeader) {
        authService.logout(authHeader);
        return ResponseEntity.ok("登出成功");
    }

    @GetMapping("/activate")
    public ResponseEntity<String> activate(@RequestParam("code") String code) {
        authService.activateAccount(code);
        return ResponseEntity.ok("账号激活成功，请登录！");
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody @Valid ForgotPasswordRequest request) {
        authService.sendResetPasswordEmail(request.getEmail());
        return ResponseEntity.ok("重置密码邮件已发送，请查收");
    }

    @RequestMapping(value = "/reset-password", method = {RequestMethod.GET, RequestMethod.POST})
    public ResponseEntity<?> resetPassword(
            @RequestParam("code") String code,
            @RequestParam(value = "newPassword", required = false) String newPassword) {

        // 如果是GET请求或者没有提供新密码，显示重设密码表单
        if (newPassword == null || newPassword.trim().isEmpty()) {
            try {
                // 验证重置码是否有效
                String resetKey = "user:reset:" + code;
                // 简单验证（可选）
                // String email = redisTemplate.opsForValue().get(resetKey);
                // if (email == null) {
                //     return ResponseEntity.badRequest().body("重置链接无效或已过期");
                // }

                // 返回重设密码表单页面
                String html = "<!DOCTYPE html>" +
                        "<html><head>" +
                        "<title>Reset Password</title>" +
                        "<meta charset='UTF-8'>" +
                        "<style>" +
                        "body { font-family: Arial, sans-serif; max-width: 400px; margin: 50px auto; padding: 20px; }" +
                        "h2 { color: #333; text-align: center; }" +
                        "form { background: #f9f9f9; padding: 20px; border-radius: 8px; }" +
                        "label { display: block; margin-bottom: 5px; font-weight: bold; }" +
                        "input[type='password'] { width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }" +
                        "input[type='submit'] { width: 100%; padding: 12px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }" +
                        "input[type='submit']:hover { background: #0056b3; }" +
                        ".note { color: #666; font-size: 14px; margin-top: 10px; }" +
                        "</style>" +
                        "</head><body>" +
                        "<h2>Reset Password</h2>" +
                        "<form action='/api/v1/auth/reset-password' method='post'>" +
                        "<input type='hidden' name='code' value='" + code + "'>" +
                        "<label for='newPassword'>New Password:</label>" +
                        "<input type='password' id='newPassword' name='newPassword' required minlength='6' placeholder='Enter new password (at least 6 characters)'>" +
                        "<input type='submit' value='Reset Password'>" +
                        "<div class='note'>Password must be at least 6 characters long, preferably containing letters and numbers</div>" +
                        "</form></body></html>";
                return ResponseEntity.ok().header("Content-Type", "text/html; charset=UTF-8").body(html);
            } catch (Exception e) {
                return ResponseEntity.badRequest().header("Content-Type", "text/html; charset=UTF-8")
                        .body("<!DOCTYPE html><html><head><title>Error</title><meta charset='UTF-8'></head><body>" +
                                "<h2>Reset link is invalid or expired</h2><p>Please request a new password reset.</p></body></html>");
            }
        } else {
            // 如果是POST请求且提供了新密码，执行密码重置
            try {
                authService.resetPassword(code, newPassword);
                return ResponseEntity.ok().header("Content-Type", "text/html; charset=UTF-8")
                        .body("<!DOCTYPE html><html><head>" +
                                "<title>Success</title><meta charset='UTF-8'>" +
                                "<style>" +
                                "body { font-family: Arial, sans-serif; max-width: 400px; margin: 50px auto; padding: 20px; text-align: center; }" +
                                "h2 { color: #28a745; margin-bottom: 20px; }" +
                                "p { color: #666; margin-bottom: 15px; }" +
                                ".success-icon { font-size: 48px; color: #28a745; margin-bottom: 20px; }" +
                                ".close-btn { background: #28a745; color: white; border: none; padding: 12px 24px; border-radius: 4px; cursor: pointer; font-size: 16px; margin-top: 20px; }" +
                                ".close-btn:hover { background: #218838; }" +
                                ".countdown { color: #999; font-size: 14px; margin-top: 15px; }" +
                                "</style>" +
                                "<script>" +
                                "let countdown = 5;" +
                                "function updateCountdown() {" +
                                "  const countdownEl = document.getElementById('countdown');" +
                                "  if (countdown > 0) {" +
                                "    countdownEl.textContent = 'You can close this window in ' + countdown + ' seconds';" +
                                "    countdown--;" +
                                "    setTimeout(updateCountdown, 1000);" +
                                "  } else {" +
                                "    countdownEl.textContent = 'You can now close this window manually.';" +
                                "  }" +
                                "}" +
                                "window.onload = function() {" +
                                "  updateCountdown();" +
                                "};" +
                                "</script>" +
                                "</head><body>" +
                                "<div class='success-icon'>✓</div>" +
                                "<h2>Password Reset Successful!</h2>" +
                                "<p>Your password has been successfully reset.</p>" +
                                "<p>Now you can back to login with your new password.</p>" +
                                "<button class='close-btn' onclick='window.close()'>Close Window</button>" +
                                "<div class='countdown' id='countdown'></div>" +
                                "</body></html>");
            } catch (Exception e) {
                return ResponseEntity.badRequest().header("Content-Type", "text/html; charset=UTF-8")
                        .body("<!DOCTYPE html><html><head><title>Error</title><meta charset='UTF-8'></head><body>" +
                                "<h2>Password Reset Failed</h2><p>" + e.getMessage() + "</p>" +
                                "<p><a href='javascript:history.back()'>Go Back and Retry</a></p></body></html>");
            }
        }
    }

    // 保留原有的POST API接口，供API调用使用
    @PostMapping("/reset-password-api")
    public ResponseEntity<?> resetPasswordApi(@RequestBody @Valid ResetPasswordRequest request) {
        authService.resetPassword(request.getCode(), request.getNewPassword());
        return ResponseEntity.ok("Password reset successful, please log in");
    }



}
