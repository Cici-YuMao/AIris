package com.airis.user.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @description: 用户名响应
 * @author: maoyu
 * @date: 2025/07/05
 * @time: 20:52
 * Copyright (C) 2025 Meituan
 * All rights reserved
 */
@Data
@AllArgsConstructor
public class UsernameResponse {
    private Long userId;
    private String username;
}
