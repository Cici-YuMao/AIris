package com.airis.user.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class LoginRequest {
    @NotBlank(message = "邮箱或用户名不能为空")
    private String identifier; // 支持邮箱或用户名

    @NotBlank(message = "密码不能为空")
    private String password;
}
