package com.airis.user.service;

import com.airis.user.dto.UserSettingsResponse;
import com.airis.user.dto.UserSettingsUpdateRequest;

public interface UserSettingsService {
    UserSettingsResponse getUserSettings(Long userId);
    void updateUserSettings(Long userId, UserSettingsUpdateRequest request);
}
