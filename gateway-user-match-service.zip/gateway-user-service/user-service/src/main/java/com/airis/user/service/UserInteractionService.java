package com.airis.user.service;

import com.airis.user.dto.CommentResponse;
import java.util.List;
import java.util.Map;

/**
 * 用户互动服务接口
 */
public interface UserInteractionService {
    void like(Long userId, Long targetUserId);
    void comment(Long userId, Long targetUserId, String content);
    void addMessageCount(Long userId, Long targetUserId, Long count);
    void setMessageCount(Long userId, Long targetUserId, Long count);

    int getLikeCount(Long userId); // 被点赞数
    int getCommentCount(Long userId); // 被评论数
    int getPopularity(Long userId); // 热度

    Map<Long, Long> getMessageCounts(Long userId); // 我对每个人发的消息数
    List<Long> getLikedUsers(Long userId);    // 我点赞过的用户ID
    Map<Long, Long> getCommentedUsers(Long userId); // 我评论了谁：key=被评论用户id, value=次数

    // 新增：获取用户收到的评论详情
    List<CommentResponse> getReceivedComments(Long userId);
}
