package com.airis.user.controller;

import com.airis.user.dto.UserSettingsResponse;
import com.airis.user.service.UserSettingsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/internal-api/v1/users")
public class InternalUserSettingsController {

    @Autowired
    private UserSettingsService userSettingsService;

    @GetMapping("/{userId}/settings")
    public UserSettingsResponse getUserSettingsInternal(@PathVariable Long userId) {
        return userSettingsService.getUserSettings(userId);
    }
}
