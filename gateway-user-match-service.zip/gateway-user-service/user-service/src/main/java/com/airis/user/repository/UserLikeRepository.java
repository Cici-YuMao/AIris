package com.airis.user.repository;

import com.airis.user.entity.UserLike;
import io.lettuce.core.dynamic.annotation.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface UserLikeRepository extends JpaRepository<UserLike, Long> {
    // 统计某个用户收到的点赞数
    @Query("SELECT COUNT(ul) FROM UserLike ul WHERE ul.likedUserId = :userId")
    Long countByLikedUserId(@Param("userId") Long userId);
}

