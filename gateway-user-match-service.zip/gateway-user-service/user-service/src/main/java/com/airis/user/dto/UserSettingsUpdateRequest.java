package com.airis.user.dto;

import lombok.Data;

@Data
public class UserSettingsUpdateRequest {
    private Boolean notificationEmail;
    private Boolean notificationPush;
    private Boolean notificationSms;
    private String privacyLevel;
    private Boolean displayOnlineStatus;
    private Boolean displayLastActive;
}
