package com.airis.user.service;

import com.airis.user.dto.NotificationMessage;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class NotificationSenderService {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    public void sendNotification(@RequestBody NotificationMessage msg) {
        rabbitTemplate.convertAndSend("notification.exchange", "notification.routingKey", msg);
    }
}
