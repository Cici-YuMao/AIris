package com.airis.user.service;

import com.airis.user.dto.UserPreferenceResponse;
import com.airis.user.dto.UserPreferenceUpdateRequest;

public interface UserPreferenceService {
    UserPreferenceResponse getUserPreference(Long userId);
    void updateUserPreference(Long userId, UserPreferenceUpdateRequest request);
}
