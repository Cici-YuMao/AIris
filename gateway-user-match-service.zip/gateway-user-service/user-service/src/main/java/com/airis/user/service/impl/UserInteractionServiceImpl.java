package com.airis.user.service.impl;

import com.airis.user.dto.CommentResponse;
import com.airis.user.dto.NotificationMessage;
import com.airis.user.entity.User;
import com.airis.user.exception.DuplicateLikeException;
import com.airis.user.repository.UserRepository;
import com.airis.user.service.NotificationSenderService;
import com.airis.user.service.UserInteractionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserInteractionServiceImpl implements UserInteractionService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private NotificationSenderService notificationSenderService;

    // 新增注入
    @Autowired
    private UserRepository userRepository;

    @Override
    public List<Long> getLikedUsers(Long userId) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT liked_user_id FROM user_likes WHERE user_id=?", userId
        );
        List<Long> result = new ArrayList<>();
        for (Map<String, Object> row : rows) {
            result.add(((Number) row.get("liked_user_id")).longValue());
        }
        return result;
    }


    @Override
    public Map<Long, Long> getCommentedUsers(Long userId) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT commented_user_id, COUNT(*) as cnt FROM user_comments WHERE user_id=? GROUP BY commented_user_id", userId
        );
        Map<Long, Long> result = new HashMap<>();
        for (Map<String, Object> row : rows) {
            result.put(((Number) row.get("commented_user_id")).longValue(), ((Number) row.get("cnt")).longValue());
        }
        return result;
    }



    @Override
    public void like(Long userId, Long targetUserId) {
        System.out.println("点赞服务 - 用户ID: " + userId + ", 目标用户ID: " + targetUserId);

        // 检查是否已经点赞过
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM user_likes WHERE user_id=? AND liked_user_id=?",
                Integer.class, userId, targetUserId
        );
        System.out.println("数据库查询结果 - 已存在点赞记录数: " + count);

        if (count != null && count > 0) {
            System.out.println("重复点赞检测 - 用户 " + userId + " 已经点赞过用户 " + targetUserId);
            throw new DuplicateLikeException("Have gaven like before");
        }

        // 使用Java的LocalDateTime
        LocalDateTime now = LocalDateTime.now();

        try {
            jdbcTemplate.update(
                    "INSERT INTO user_likes(user_id, liked_user_id, created_at) VALUES (?, ?, ?)",
                    userId, targetUserId, now
            );
            System.out.println("点赞记录插入成功 - 用户ID: " + userId + ", 目标用户ID: " + targetUserId);
        } catch (Exception e) {
            System.err.println("点赞记录插入失败: " + e.getMessage());
            // 如果是唯一约束违反，抛出重复点赞异常
            if (e.getMessage().contains("Duplicate") || e.getMessage().contains("unique")) {
                throw new DuplicateLikeException("Have gaven like before");
            }
            throw e;
        }

        // 更新被点赞用户的热度值
        updateUserPopularity(targetUserId);

        NotificationMessage msg = new NotificationMessage();
        msg.setReceiverId(targetUserId);
        msg.setSenderId(userId);
        msg.setType("like");
        msg.setTitle("You received a new like");
        msg.setContent("User " + userId + " liked you");
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("likeFrom", userId);
        metadata.put("likeTo", targetUserId);
        msg.setMetadata(metadata);

        notificationSenderService.sendNotification(msg);
    }

    @Override
    public void comment(Long userId, Long targetUserId, String content) {
        // 使用Java的LocalDateTime
        LocalDateTime now = LocalDateTime.now();

        jdbcTemplate.update(
                "INSERT INTO user_comments(user_id, commented_user_id, comment_text, created_at) VALUES (?, ?, ?, ?)",
                userId, targetUserId, content, now
        );

        // 更新被评论用户的热度值
        updateUserPopularity(targetUserId);

        NotificationMessage msg = new NotificationMessage();
        msg.setReceiverId(targetUserId);
        msg.setSenderId(userId);
        msg.setType("comment");
        msg.setTitle("You received a new comment");
        msg.setContent("User " + userId + " commented on you: " + content);
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("commentFrom", userId);
        metadata.put("commentTo", targetUserId);
        msg.setMetadata(metadata);

        notificationSenderService.sendNotification(msg);
    }

    @Override
    public void addMessageCount(Long userId, Long targetUserId, Long count) {
        Integer exist = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM user_message_counts WHERE user_id=? AND target_user_id=?",
                Integer.class, userId, targetUserId);
        if (exist != null && exist > 0) {
            jdbcTemplate.update(
                    "UPDATE user_message_counts SET message_count = message_count + ?, updated_at = NOW() WHERE user_id=? AND target_user_id=?",
                    count, userId, targetUserId
            );
        } else {
            jdbcTemplate.update(
                    "INSERT INTO user_message_counts(user_id, target_user_id, message_count) VALUES (?, ?, ?)",
                    userId, targetUserId, count
            );
        }
    }

    @Override
    public void setMessageCount(Long userId, Long targetUserId, Long count) {
        Integer exist = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM user_message_counts WHERE user_id=? AND target_user_id=?",
                Integer.class, userId, targetUserId);
        if (exist != null && exist > 0) {
            jdbcTemplate.update(
                    "UPDATE user_message_counts SET message_count = ?, updated_at = NOW() WHERE user_id=? AND target_user_id=?",
                    count, userId, targetUserId
            );
        } else {
            jdbcTemplate.update(
                    "INSERT INTO user_message_counts(user_id, target_user_id, message_count) VALUES (?, ?, ?)",
                    userId, targetUserId, count
            );
        }
    }

    @Override
    public Map<Long, Long> getMessageCounts(Long userId) {
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(
                "SELECT target_user_id, message_count FROM user_message_counts WHERE user_id=?", userId
        );
        Map<Long, Long> result = new HashMap<>();
        for (Map<String, Object> row : rows) {
            result.put(((Number) row.get("target_user_id")).longValue(), ((Number) row.get("message_count")).longValue());
        }
        return result;
    }

    @Override
    public int getLikeCount(Long userId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM user_likes WHERE liked_user_id=?", Integer.class, userId
        );
        return count != null ? count : 0;
    }

    @Override
    public int getCommentCount(Long userId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM user_comments WHERE commented_user_id=?", Integer.class, userId
        );
        return count != null ? count : 0;
    }

    @Override
    public int getPopularity(Long userId) {
        return getLikeCount(userId) + getCommentCount(userId);
    }

    @Override
    public List<CommentResponse> getReceivedComments(Long userId) {
        String sql = "SELECT uc.id, uc.user_id, u.username, uc.commented_user_id, " +
                     "uc.comment_text, uc.created_at " +
                     "FROM user_comments uc " +
                     "LEFT JOIN users u ON uc.user_id = u.id " +
                     "WHERE uc.commented_user_id = ? " +
                     "ORDER BY uc.created_at DESC";

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, userId);
        List<CommentResponse> comments = new ArrayList<>();

        for (Map<String, Object> row : rows) {
            CommentResponse comment = new CommentResponse();
            comment.setId(((Number) row.get("id")).longValue());
            comment.setUserId(((Number) row.get("user_id")).longValue());
            comment.setUsername((String) row.get("username"));
            comment.setCommentedUserId(((Number) row.get("commented_user_id")).longValue());
            comment.setCommentText((String) row.get("comment_text"));
            comment.setCreatedAt(((java.sql.Timestamp) row.get("created_at")).toLocalDateTime());
            comments.add(comment);
        }

        return comments;
    }

    /**
     * 更新用户热度值
     */
    private void updateUserPopularity(Long userId) {
        try {
            int popularity = getPopularity(userId);
            User user = userRepository.findById(userId).orElse(null);
            if (user != null) {
                user.setPopularity(popularity);
                userRepository.save(user);
                System.out.println("更新用户热度成功，用户ID: " + userId + ", 新热度: " + popularity);
            }
        } catch (Exception e) {
            System.err.println("更新用户热度失败，用户ID: " + userId + ", 错误: " + e.getMessage());
        }
    }

}
