package com.airis.user.service;

import com.airis.user.dto.UserInfoResponse;
import com.airis.user.dto.UserUpdateRequest;

import java.util.List;

public interface UserService {
    UserInfoResponse getUserInfo(Long userId);
    void updateUserInfo(Long userId, UserUpdateRequest request);
    void deleteUser(Long userId);
    String getUsernameById(Long userId);
    List<Long> getAllUserIds();

}
