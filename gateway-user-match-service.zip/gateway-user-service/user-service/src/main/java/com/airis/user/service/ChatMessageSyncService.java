package com.airis.user.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class ChatMessageSyncService {

    @Autowired
    private UserInteractionService userInteractionService;

    @Autowired
    private RestTemplate restTemplate;

    public void syncChatMessageCount(Long userAId, Long userBId) {
        String url = "http://10.144.113.108:9330/api/v1/messages/chat-detail?userAId=" + userAId + "&userBId=" + userBId;
        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            try {
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode root = objectMapper.readTree(response.getBody());

                long userAMessageCount = root.path("userAMessageCount").asLong();
                long userBMessageCount = root.path("userBMessageCount").asLong();
                long aId = root.path("userAId").asLong();
                long bId = root.path("userBId").asLong();

                // 推荐用 setMessageCount，避免重复累计
                userInteractionService.setMessageCount(aId, bId, userAMessageCount);
                userInteractionService.setMessageCount(bId, aId, userBMessageCount);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Autowired
    private UserService userService; // 需要有获取所有用户ID的方法

    // 每12小时自动同步一次
    @Scheduled(cron = "0 0 */12 * * ?")
    public void syncAllUserChatMessageCounts() {
        // 获取所有用户ID
        List<Long> userIds = userService.getAllUserIds();
        // 两两组合遍历
        for (int i = 0; i < userIds.size(); i++) {
            for (int j = i + 1; j < userIds.size(); j++) {
                Long userAId = userIds.get(i);
                Long userBId = userIds.get(j);
                // 调用你的同步方法
                syncChatMessageCount(userAId, userBId);
            }
        }
    }
}
