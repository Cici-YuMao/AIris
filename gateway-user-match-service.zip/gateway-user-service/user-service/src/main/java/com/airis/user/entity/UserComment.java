package com.airis.user.entity;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "user_comments")
public class UserComment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id")
    private Long userId;        // 评论者ID

    @Column(name = "commented_user_id")
    private Long commentedUserId;   // 被评论的用户ID

    @Column(name = "comment_text", columnDefinition = "TEXT")
    private String commentText;     // 评论内容

    @Column(name = "created_at")
    private LocalDateTime createdAt;
}

