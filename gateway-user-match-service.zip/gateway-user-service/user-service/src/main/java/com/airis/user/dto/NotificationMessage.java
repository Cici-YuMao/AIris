package com.airis.user.dto;

import lombok.Data;
import java.io.Serializable;
import java.util.Map;

@Data
public class NotificationMessage implements Serializable {
    private Long receiverId;
    private Long senderId;
    private String type;      // "match" / "chat" / "media" / "like" / "comment"
    private String title;
    private String content;
    private Map<String, Object> metadata;
}
