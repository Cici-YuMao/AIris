package com.airis.user.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 刷新Token响应
 */
@Data
@AllArgsConstructor
public class RefreshTokenResponse {
    private String accessToken;
    private String refreshToken;
}
