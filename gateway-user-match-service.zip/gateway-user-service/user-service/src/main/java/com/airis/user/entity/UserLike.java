package com.airis.user.entity;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "user_likes",
       uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "liked_user_id"}))
public class UserLike {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id")
    private Long userId;        // 点赞者ID

    @Column(name = "liked_user_id")
    private Long likedUserId;   // 被点赞的用户ID

    @Column(name = "created_at")
    private LocalDateTime createdAt;
}
