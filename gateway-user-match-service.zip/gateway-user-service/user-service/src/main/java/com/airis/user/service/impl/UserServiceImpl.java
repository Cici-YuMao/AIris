package com.airis.user.service.impl;

import com.airis.user.dto.UserInfoResponse;
import com.airis.user.dto.UserUpdateRequest;
import com.airis.user.entity.User;
import com.airis.user.entity.UserSettings;
import com.airis.user.repository.UserPreferenceRepository;
import com.airis.user.repository.UserRepository;
import com.airis.user.repository.UserSettingsRepository;
import com.airis.user.service.AlgorithmPushService;
import com.airis.user.service.MatchServiceClient;
import com.airis.user.service.UserInteractionService;
import com.airis.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserSettingsRepository userSettingsRepository;

    @Autowired
    private UserPreferenceRepository userPreferenceRepository;

    @Autowired
    private UserInteractionService userInteractionService;

    @Autowired
    private AlgorithmPushService algorithmPushService;

    @Autowired
    private MatchServiceClient matchServiceClient;  // 添加这个注入

    @Override
    public UserInfoResponse getUserInfo(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("用户不存在"));
        UserInfoResponse resp = new UserInfoResponse();
        resp.setId(user.getId());
        resp.setUsername(user.getUsername());
        resp.setEmail(user.getEmail());
        resp.setPhone(user.getPhone());
        resp.setAccountStatus(user.getAccountStatus());
        resp.setCreatedAt(user.getCreatedAt().toString());
        resp.setUpdatedAt(user.getUpdatedAt().toString());

        // 详细个人信息字段
        resp.setName(user.getName());
        resp.setGender(user.getGender());
        resp.setAge(user.getAge());
        resp.setSexualOrientation(user.getSexualOrientation());
        resp.setHeight(user.getHeight());
        resp.setWeight(user.getWeight());
        resp.setCity(user.getCity());
        resp.setEducation(user.getEducation());
        resp.setOccupation(user.getOccupation());
        resp.setHobbies(user.getHobbies());
        resp.setPets(user.getPets());
        resp.setFamilyStatus(user.getFamilyStatus());
        resp.setIpAddress(user.getIpAddress());

        // 新增互动统计字段
        resp.setLikeCount(userInteractionService.getLikeCount(userId));
        resp.setCommentCount(userInteractionService.getCommentCount(userId));
        resp.setPopularity(userInteractionService.getPopularity(userId));
        resp.setMessageCounts(userInteractionService.getMessageCounts(userId));

        // 新增：评论详情
        resp.setComments(userInteractionService.getReceivedComments(userId));

        return resp;
    }

    @Override
    public void updateUserInfo(Long userId, UserUpdateRequest request) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("用户不存在"));
        if (request.getUsername() != null) user.setUsername(request.getUsername());
        if (request.getPhone() != null) user.setPhone(request.getPhone());
        if (request.getName() != null) user.setName(request.getName());
        if (request.getGender() != null) user.setGender(request.getGender());
        if (request.getAge() != null) user.setAge(request.getAge());
        if (request.getSexualOrientation() != null) user.setSexualOrientation(request.getSexualOrientation());
        if (request.getHeight() != null) user.setHeight(request.getHeight());
        if (request.getWeight() != null) user.setWeight(request.getWeight());
        if (request.getCity() != null) user.setCity(request.getCity());
        if (request.getEducation() != null) user.setEducation(request.getEducation());
        if (request.getOccupation() != null) user.setOccupation(request.getOccupation());
        if (request.getHobbies() != null) user.setHobbies(request.getHobbies());
        if (request.getPets() != null) user.setPets(request.getPets());
        if (request.getFamilyStatus() != null) user.setFamilyStatus(request.getFamilyStatus());
        userRepository.save(user);

        // 信息或偏好修改后推送算法服务
        algorithmPushService.pushUserData(userId, "update");

        // 清空该用户的匹配缓存
        matchServiceClient.clearUserMatchCache(userId);
    }

    @Override
    public void deleteUser(Long userId) {
        // 删除用户主表
        userRepository.deleteById(userId);
        // 删除用户设置
        UserSettings settings = userSettingsRepository.findByUserId(userId);
        if (settings != null) userSettingsRepository.delete(settings);
        // 删除用户偏好
        userPreferenceRepository.findByUserId(userId)
                .ifPresent(userPreferenceRepository::delete);
        // 你可以根据实际情况，删除更多相关数据
        // 删除用户后推送算法服务（operation: delete）
        algorithmPushService.pushUserData(userId, "delete");

    }

    @Override
    public String getUsernameById(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        return user.getUsername();
    }

    @Override
    public List<Long> getAllUserIds() {
        return userRepository.findAll().stream().map(User::getId).collect(java.util.stream.Collectors.toList());
    }



}
