package com.airis.user.dto;

import lombok.Data;

@Data
public class UserUpdateRequest {
    private String username;
    private String phone;

    // 个人信息可修改字段
    private String name;                  // 姓名
    private String gender;                // 性别
    private Integer age;                  // 年龄
    private String sexualOrientation;     // 性取向
    private Double height;                // 身高
    private Double weight;                // 体重
    private String city;                  // 城市
    private String education;             // 学历
    private String occupation;            // 职业
    private String hobbies;               // 爱好（长文本）
    private String pets;                  // 宠物（选填）
    private String familyStatus;          // 家庭情况（选填）
}
