package com.airis.user.dto;

import lombok.Data;

@Data
public class CommentRequest {
    private String content;
}
