package com.airis.user.service.impl;

import com.airis.user.dto.UserInfoResponse;
import com.airis.user.dto.UserSettingsResponse;
import com.airis.user.dto.UserSettingsUpdateRequest;
import com.airis.user.entity.User;
import com.airis.user.entity.UserSettings;
import com.airis.user.repository.UserRepository;
import com.airis.user.repository.UserSettingsRepository;
import com.airis.user.service.UserSettingsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserSettingsServiceImpl implements UserSettingsService {

    @Autowired
    private UserSettingsRepository userSettingsRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserSettingsResponse getUserSettings(Long userId) {
        UserSettings settings = userSettingsRepository.findByUserId(userId);
        if (settings == null) {
            throw new RuntimeException("未找到用户设置");
        }
        UserSettingsResponse resp = new UserSettingsResponse();
        resp.setNotificationEmail(settings.getNotificationEmail());
        resp.setNotificationPush(settings.getNotificationPush());
        resp.setNotificationSms(settings.getNotificationSms());
        resp.setPrivacyLevel(settings.getPrivacyLevel());
        resp.setDisplayOnlineStatus(settings.getDisplayOnlineStatus());
        resp.setDisplayLastActive(settings.getDisplayLastActive());
        // 查出email并返回
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("未找到用户"));
        resp.setEmail(user.getEmail());

        return resp;
    }

    @Override
    public void updateUserSettings(Long userId, UserSettingsUpdateRequest request) {
        UserSettings settings = userSettingsRepository.findByUserId(userId);
        if (settings == null) {
            throw new RuntimeException("未找到用户设置");
        }
        if (request.getNotificationEmail() != null) settings.setNotificationEmail(request.getNotificationEmail());
        if (request.getNotificationPush() != null) settings.setNotificationPush(request.getNotificationPush());
        if (request.getNotificationSms() != null) settings.setNotificationSms(request.getNotificationSms());
        if (request.getPrivacyLevel() != null) settings.setPrivacyLevel(request.getPrivacyLevel());
        if (request.getDisplayOnlineStatus() != null) settings.setDisplayOnlineStatus(request.getDisplayOnlineStatus());
        if (request.getDisplayLastActive() != null) settings.setDisplayLastActive(request.getDisplayLastActive());
        userSettingsRepository.save(settings);
    }
}
