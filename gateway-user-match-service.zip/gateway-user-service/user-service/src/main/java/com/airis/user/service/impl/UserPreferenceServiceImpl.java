package com.airis.user.service.impl;

import com.airis.user.dto.UserPreferenceResponse;
import com.airis.user.dto.UserPreferenceUpdateRequest;
import com.airis.user.entity.UserPreference;
import com.airis.user.repository.UserPreferenceRepository;
import com.airis.user.service.AlgorithmPushService;
import com.airis.user.service.MatchServiceClient;
import com.airis.user.service.UserPreferenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class UserPreferenceServiceImpl implements UserPreferenceService {

    @Autowired
    private UserPreferenceRepository userPreferenceRepository;

    @Autowired
    private AlgorithmPushService algorithmPushService;

    @Autowired
    private MatchServiceClient matchServiceClient;


    @Override
    public UserPreferenceResponse getUserPreference(Long userId) {
        UserPreference pref = userPreferenceRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("未找到用户偏好"));
        UserPreferenceResponse resp = new UserPreferenceResponse();
        resp.setAgeRange(pref.getAgeRange());
        resp.setHeightRange(pref.getHeightRange());
        resp.setWeightRange(pref.getWeightRange());
        resp.setSexualOrientation(pref.getSexualOrientation());
        resp.setPreferredEducation(pref.getPreferredEducation());
        resp.setPreferredOccupation(pref.getPreferredOccupation());
        resp.setPreferredCities(pref.getPreferredCities());
        resp.setHobbies(pref.getHobbies());
        resp.setDealBreakers(pref.getDealBreakers());
        resp.setTopPriorities(pref.getTopPriorities());
        return resp;
    }

    @Override
    public void updateUserPreference(Long userId, UserPreferenceUpdateRequest request) {
        UserPreference pref = userPreferenceRepository.findByUserId(userId)
                .orElse(new UserPreference());
        pref.setUserId(userId);
        if (request.getAgeRange() != null) pref.setAgeRange(request.getAgeRange());
        if (request.getHeightRange() != null) pref.setHeightRange(request.getHeightRange());
        if (request.getWeightRange() != null) pref.setWeightRange(request.getWeightRange());
        if (request.getSexualOrientation() != null) pref.setSexualOrientation(request.getSexualOrientation());
        if (request.getPreferredEducation() != null) pref.setPreferredEducation(request.getPreferredEducation());
        if (request.getPreferredOccupation() != null) pref.setPreferredOccupation(request.getPreferredOccupation());
        if (request.getPreferredCities() != null) pref.setPreferredCities(request.getPreferredCities());
        if (request.getHobbies() != null) pref.setHobbies(request.getHobbies());
        if (request.getDealBreakers() != null) pref.setDealBreakers(request.getDealBreakers());
        if (request.getTopPriorities() != null) pref.setTopPriorities(request.getTopPriorities());
        pref.setUpdatedAt(new Date());
        userPreferenceRepository.save(pref);

        // 信息或偏好修改后推送算法服务
        algorithmPushService.pushUserData(userId, "update");

        // 清空该用户的匹配缓存
        matchServiceClient.clearUserMatchCache(userId);
    }
}
