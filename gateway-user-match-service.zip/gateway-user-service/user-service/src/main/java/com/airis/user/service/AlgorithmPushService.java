package com.airis.user.service;

import com.airis.user.entity.User;
import com.airis.user.entity.UserPreference;
import com.airis.user.repository.UserPreferenceRepository;
import com.airis.user.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class AlgorithmPushService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserPreferenceRepository userPreferenceRepository;
    @Autowired
    private UserInteractionService userInteractionService;
    @Autowired
    private RestTemplate restTemplate;

    // 算法服务批量接收接口地址（请替换为实际地址）
    private static final String ALGO_BATCH_URL = "http://10.144.136.83:9010/algorithm/batch-upload";

    /**
     * 立即推送单个用户数据（注册/修改时用）
     */
    public void pushUserData(Long userId, String operation) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null && !"delete".equals(operation)) return;

        Map<String, Object> data = new HashMap<>();
        data.put("operation", operation);

        if (!"delete".equals(operation)) {
            // 个人信息
            data.put("id", user.getId());
            data.put("username", user.getUsername());
            data.put("gender", user.getGender());
            data.put("age", user.getAge());
            data.put("city", user.getCity());
            data.put("education", user.getEducation());
            data.put("occupation", user.getOccupation());
            data.put("hobbies", user.getHobbies());
            data.put("popularity", userInteractionService.getPopularity(user.getId()));
            // 新增：我点赞了谁、我评论了谁
            data.put("height", user.getHeight());
            data.put("weight", user.getWeight());
            data.put("likedUsers", userInteractionService.getLikedUsers(user.getId()));
            data.put("commentedUsers", userInteractionService.getCommentedUsers(user.getId()));
            data.put("messageCounts", userInteractionService.getMessageCounts(user.getId()));

            // 偏好
            UserPreference pref = userPreferenceRepository.findByUserId(user.getId()).orElse(null);
            if (pref != null) {
                Map<String, Object> preference = new HashMap<>();
                preference.put("ageRange", pref.getAgeRange());
                preference.put("heightRange", pref.getHeightRange());
                preference.put("weightRange", pref.getWeightRange());
                preference.put("preferredCities", pref.getPreferredCities());
                preference.put("hobbies", pref.getHobbies());
                preference.put("dealBreakers", pref.getDealBreakers());
                preference.put("topPriorities", pref.getTopPriorities());
                preference.put("sexualOrientation", user.getSexualOrientation());
//                preference.put("preferredEducation", pref.getPreferredEducation());
//                preference.put("preferredOccupation", pref.getPreferredOccupation());
                data.put("preference", preference);
            }
        } else {
            // 删除只需要id
            data.put("id", userId);
        }

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String json = objectMapper.writeValueAsString(Collections.singletonList(data));

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<String> requestEntity = new HttpEntity<>(json, headers);

            // 添加重试机制
            int maxRetries = 3;
            int retryCount = 0;
            boolean success = false;

            while (retryCount < maxRetries && !success) {
                try {
                    ResponseEntity<String> response = restTemplate.postForEntity(ALGO_BATCH_URL, requestEntity, String.class);

                    if (response.getStatusCode().is2xxSuccessful()) {
                        System.out.println("单用户" + operation + "推送算法服务成功：" + userId);
                        success = true;
                    } else {
                        System.err.println("单用户" + operation + "推送算法服务失败，状态码：" + response.getStatusCode());
                        retryCount++;
                    }
                } catch (Exception retryException) {
                    retryCount++;
                    System.err.println("推送算法服务重试 " + retryCount + "/" + maxRetries + " 失败: " + retryException.getMessage());

                    if (retryCount < maxRetries) {
                        try {
                            Thread.sleep(2000); // 等待2秒后重试
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                            break;
                        }
                    }
                }
            }

            if (!success) {
                System.err.println("推送算法服务最终失败，用户ID: " + userId + "，操作: " + operation);
            }

        } catch (Exception e) {
            System.err.println("推送算法服务异常，用户ID: " + userId + "，操作: " + operation + "，错误: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * 每12小时全量推送所有用户数据
     */
    @Scheduled(cron = "0 0 */12 * * ?")
    public void pushAllUserDataToAlgorithm() {
        List<User> users = userRepository.findAll();
        List<Map<String, Object>> userDataList = new ArrayList<>();
        for (User user : users) {
            Map<String, Object> data = new HashMap<>();
            data.put("operation", "update");

            data.put("id", user.getId());
            data.put("username", user.getUsername());
            data.put("gender", user.getGender());
            data.put("age", user.getAge());
            data.put("city", user.getCity());
            data.put("education", user.getEducation());
            data.put("occupation", user.getOccupation());
            data.put("hobbies", user.getHobbies());
            data.put("popularity", userInteractionService.getPopularity(user.getId()));
            // 新增：我点赞了谁、我评论了谁
            data.put("height", user.getHeight());
            data.put("weight", user.getWeight());
            data.put("likedUsers", userInteractionService.getLikedUsers(user.getId()));         // Map<被点赞userId, 次数>
            data.put("commentedUsers", userInteractionService.getCommentedUsers(user.getId())); // Map<被评论userId, 次数>
            data.put("messageCounts", userInteractionService.getMessageCounts(user.getId()));

            UserPreference pref = userPreferenceRepository.findByUserId(user.getId()).orElse(null);
            if (pref != null) {
                Map<String, Object> preference = new HashMap<>();
                preference.put("ageRange", pref.getAgeRange());
                preference.put("heightRange", pref.getHeightRange());
                preference.put("weightRange", pref.getWeightRange());
                preference.put("preferredCities", pref.getPreferredCities());
                preference.put("hobbies", pref.getHobbies());
                preference.put("dealBreakers", pref.getDealBreakers());
                preference.put("topPriorities", pref.getTopPriorities());
                preference.put("sexualOrientation", user.getSexualOrientation());
//                preference.put("preferredEducation", pref.getPreferredEducation());
//                preference.put("preferredOccupation", pref.getPreferredOccupation());
                data.put("preference", preference);
            }
            userDataList.add(data);
        }

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String json = objectMapper.writeValueAsString(userDataList);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<String> requestEntity = new HttpEntity<>(json, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(ALGO_BATCH_URL, requestEntity, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                System.out.println("全量推送算法服务成功");
            } else {
                System.err.println("全量推送算法服务失败，状态码：" + response.getStatusCode());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
