package com.airis.user.dto;

import lombok.Data;

@Data
public class UserSettingsResponse {
    private Boolean notificationEmail;
    private Boolean notificationPush;
    private Boolean notificationSms;
    private String privacyLevel;
    private Boolean displayOnlineStatus;
    private Boolean displayLastActive;
    private String email; // 新增
}
