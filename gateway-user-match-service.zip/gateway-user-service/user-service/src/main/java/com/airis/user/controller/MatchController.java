package com.airis.user.controller;

import com.airis.user.dto.MatchUserDetailResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/api/v1/match")
public class MatchController {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private HttpServletRequest request;

    @Value("${match.service.url:http://localhost:8082}")
    private String matchServiceUrl;

    // 游客广场：返回热度最高的前N个用户详细信息
    @GetMapping("/hot-users")
    public List<MatchUserDetailResponse> getHotUsers(@RequestParam(defaultValue = "10") int count) {
        String url = matchServiceUrl + "/api/v1/match/hot-users?count=" + count;
        ResponseEntity<List<MatchUserDetailResponse>> response = restTemplate.exchange(
                url, HttpMethod.GET, null, new ParameterizedTypeReference<List<MatchUserDetailResponse>>() {});
        return response.getBody();
    }

    /**
     * 推荐接口：返回50个用户卡片
     */
    @GetMapping("/recommend")
    public List<MatchUserDetailResponse> recommend(Authentication authentication) {
        String url = matchServiceUrl + "/api/v1/match/recommend";
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + getTokenFromRequest());
        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<List<MatchUserDetailResponse>> response = restTemplate.exchange(
                url, HttpMethod.GET, entity, new ParameterizedTypeReference<List<MatchUserDetailResponse>>() {});
        return response.getBody();
    }

    /**
     * 高匹配接口：返回5个高匹配用户卡片
     */
    @GetMapping("/highly-matched")
    public List<MatchUserDetailResponse> highlyMatched(Authentication authentication) {
        String url = matchServiceUrl + "/api/v1/match/highly-matched";
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + getTokenFromRequest());
        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<List<MatchUserDetailResponse>> response = restTemplate.exchange(
                url, HttpMethod.GET, entity, new ParameterizedTypeReference<List<MatchUserDetailResponse>>() {});
        return response.getBody();
    }

    /**
     * 用户详细信息
     */
    @GetMapping("/user/{userId}")
    public MatchUserDetailResponse getUserDetail(@PathVariable Long userId) {
        String url = matchServiceUrl + "/api/v1/match/user/" + userId;
        return restTemplate.getForObject(url, MatchUserDetailResponse.class);
    }

    // 工具方法：从Authentication获取userId
    private Long getUserId(Authentication authentication) {
        Object principal = authentication.getPrincipal();
        if (principal instanceof Long) {
            return (Long) principal;
        } else if (principal instanceof String) {
            return Long.valueOf((String) principal);
        } else {
            throw new RuntimeException("无法识别的用户身份");
        }
    }

    // 工具方法：从请求中获取Token
    private String getTokenFromRequest() {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.replace("Bearer ", "");
        }
        return "";
    }
}
