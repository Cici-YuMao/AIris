package com.airis.user.dto;

import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
public class RegisterRequest {
    @NotBlank(message = "用户名不能为空")
    @Size(min = 3, max = 50, message = "用户名长度应在3-50之间")
    private String username;

    @NotBlank(message = "邮箱不能为空")
    @Email(message = "邮箱格式不正确")
    private String email;

    @NotBlank(message = "密码不能为空")
    @Size(min = 6, max = 20, message = "密码长度应在6-20之间")
    private String password;

    @NotBlank(message = "验证码不能为空")
    private String verificationCode;

    private String phone;

    // 个人信息字段（建议新增）
    private String name;
    private String gender;
    private Integer age;
    private String sexualOrientation;
    private Double height;
    private Double weight;
    private String city;
    private String education;
    private String occupation;
    private String hobbies;
    private String pets;
    private String familyStatus;

    // 账号设置和偏好（可选）
    private UserSettingsUpdateRequest settings;
    private UserPreferenceUpdateRequest preference;
}

