package com.airis.user.controller;

import com.airis.user.dto.CommentRequest;
import com.airis.user.dto.MessageCountRequest;
import com.airis.user.exception.DuplicateLikeException;
import com.airis.user.service.UserInteractionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * User Interaction Controller
 */
@RestController
@RequestMapping("/api/v1/interact")
public class UserInteractionController {

    @Autowired
    private UserInteractionService userInteractionService;

    /**
     * Like API
     */
    @PostMapping("/like/{targetUserId}")
    public ResponseEntity<Map<String, Object>> likeUser(@PathVariable Long targetUserId,
                                                        Authentication authentication,
                                                        HttpServletRequest request) {
        Map<String, Object> response = new HashMap<>();
        try {
            Long userId = getUserId(authentication, request);
            System.out.println("Like request - User ID: " + userId + ", Target User ID: " + targetUserId);
            userInteractionService.like(userId, targetUserId);
            response.put("success", true);
            response.put("message", "Like successful");
            System.out.println("Like successful - User ID: " + userId + ", Target User ID: " + targetUserId);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            System.err.println("Like failed - User ID: " + getUserId(authentication, request) + ", Target User ID: " + targetUserId + ", Error: " + e.getMessage());
            e.printStackTrace();

            // Check if it's a duplicate like exception
            if (e instanceof DuplicateLikeException ||
                (e.getMessage() != null && (e.getMessage().contains("点赞") || e.getMessage().contains("Duplicate") || e.getMessage().contains("unique")))) {
                response.put("success", false);
                response.put("message", "You have already liked this user");
            } else {
                response.put("success", false);
                response.put("message", "Like failed, please try again later");
            }
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * Comment API
     */
    @PostMapping("/comment/{targetUserId}")
    public ResponseEntity<?> commentUser(@PathVariable Long targetUserId,
                                         @RequestBody CommentRequest commentRequest,
                                         Authentication authentication,
                                         HttpServletRequest request) {
        Long userId = getUserId(authentication, request);
        userInteractionService.comment(userId, targetUserId, commentRequest.getContent());
        return ResponseEntity.ok("Comment successful");
    }

    /**
     * Add Message Count API
     */
    @PostMapping("/message-count/{targetUserId}")
    public ResponseEntity<?> addMessageCount(@PathVariable Long targetUserId,
                                             @RequestBody MessageCountRequest messageCountRequest,
                                             Authentication authentication,
                                             HttpServletRequest request) {
        Long userId = getUserId(authentication, request);
        userInteractionService.addMessageCount(userId, targetUserId, messageCountRequest.getCount());
        return ResponseEntity.ok("Message count added successfully");
    }

    /**
     * Get current user ID
     */
    private Long getUserId(Authentication authentication, HttpServletRequest request) {
        // Priority: Get user ID from HTTP header (passed by gateway)
        String userIdHeader = request.getHeader("X-User-Id");
        if (userIdHeader != null && !userIdHeader.isEmpty()) {
            try {
                Long userId = Long.valueOf(userIdHeader);
                System.out.println("Got user ID from HTTP header: " + userId);
                return userId;
            } catch (NumberFormatException e) {
                System.err.println("Invalid user ID format in HTTP header: " + userIdHeader);
            }
        }

        // If no user ID in HTTP header, get from Authentication
        if (authentication != null) {
            Object principal = authentication.getPrincipal();
            System.out.println("Getting user ID from Authentication - principal type: " + principal.getClass().getName() + ", value: " + principal);

            if (principal instanceof Long) {
                return (Long) principal;
            } else if (principal instanceof String) {
                try {
                    return Long.valueOf((String) principal);
                } catch (NumberFormatException e) {
                    System.err.println("Unable to convert string to Long: " + principal);
                    throw new RuntimeException("Unrecognized user identity: " + principal);
                }
            } else {
                System.err.println("Unknown principal type: " + principal.getClass().getName());
                throw new RuntimeException("Unrecognized user identity type: " + principal.getClass().getName());
            }
        }

        throw new RuntimeException("Unable to get user identity information");
    }
}
