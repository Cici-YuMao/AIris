// UserSettings.jsx - 独立版本
import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { userAPI } from '../../services/user.js';

function UserSettings() {
  const { user, logout } = useAuth();
  const [settings, setSettings] = useState({
    notificationEmail: true,
    notificationPush: true,
    notificationSms: false,
    privacyLevel: 'PUBLIC',
    displayOnlineStatus: true,
    displayLastActive: true
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);

  // 组件加载时获取设置
  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const settingsData = await userAPI.getSettings();
      setSettings(settingsData);
    } catch (error) {
      console.error('加载设置失败:', error);
      setMessage({ type: 'error', text: '加载设置失败' });
    }
  };

  const handleSettingsChange = (e) => {
    const { name, value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : value;

    setSettings(prev => ({
      ...prev,
      [name]: newValue
    }));
  };

  const saveSettings = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    try {
      await userAPI.updateSettings(settings);
      setMessage({ type: 'success', text: '设置更新成功' });
    } catch (error) {
      console.error('保存设置失败:', error);
      setMessage({ type: 'error', text: '保存设置失败: ' + error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    const confirmed = window.confirm(
      '确定要删除账号吗？此操作不可撤销！'
    );

    if (confirmed) {
      try {
        await userAPI.deleteAccount();
        logout();
      } catch (error) {
        setMessage({ type: 'error', text: '删除账号失败: ' + error.message });
      }
    }
  };

  return (
    <div className="settings-container">
      {message && (
        <div className={`message ${message.type}`}>
          {message.text}
        </div>
      )}

      <form onSubmit={saveSettings} className="settings-form">
        <div className="form-section">
          <h3>通知设置</h3>

          <div className="form-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="notificationEmail"
                checked={settings.notificationEmail}
                onChange={handleSettingsChange}
              />
              <span>邮件通知</span>
            </label>
          </div>

          <div className="form-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="notificationPush"
                checked={settings.notificationPush}
                onChange={handleSettingsChange}
              />
              <span>推送通知</span>
            </label>
          </div>

          <div className="form-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="notificationSms"
                checked={settings.notificationSms}
                onChange={handleSettingsChange}
              />
              <span>短信通知</span>
            </label>
          </div>
        </div>

        <div className="form-section">
          <h3>隐私设置</h3>

          <div className="form-group">
            <label htmlFor="privacyLevel">隐私级别</label>
            <select
              id="privacyLevel"
              name="privacyLevel"
              value={settings.privacyLevel}
              onChange={handleSettingsChange}
            >
              <option value="PUBLIC">公开</option>
              <option value="FRIENDS">仅好友可见</option>
              <option value="PRIVATE">私密</option>
            </select>
          </div>

          <div className="form-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="displayOnlineStatus"
                checked={settings.displayOnlineStatus}
                onChange={handleSettingsChange}
              />
              <span>显示在线状态</span>
            </label>
          </div>

          <div className="form-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                name="displayLastActive"
                checked={settings.displayLastActive}
                onChange={handleSettingsChange}
              />
              <span>显示最后活跃时间</span>
            </label>
          </div>
        </div>

        <button type="submit" className="save-button" disabled={loading}>
          {loading ? '保存中...' : '保存设置'}
        </button>
      </form>

      <div className="danger-zone">
        <h3>危险操作</h3>
        <p>删除账号后将无法恢复，请谨慎操作。</p>
        <button
          type="button"
          className="delete-button"
          onClick={handleDeleteAccount}
        >
          删除账号
        </button>
      </div>
    </div>
  );
}

export default UserSettings;

