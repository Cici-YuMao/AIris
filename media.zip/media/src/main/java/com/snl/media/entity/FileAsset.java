package com.snl.media.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@Document("file_assets")
public class FileAsset {
    @Id
    private String id;

    private Long senderId;
    private Long receiverId;
    private String fileName;
    private String fileType;
    private Long fileSize;
    private String url;
    private Date createdAt;
    private String cdnKey;  // 上传到 CDN 的文件名（key）
}
