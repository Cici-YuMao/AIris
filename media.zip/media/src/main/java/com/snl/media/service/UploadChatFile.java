package com.snl.media.service;


import com.snl.media.dao.FIleAssetRepository;
import com.snl.media.entity.FileAsset;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.IOException;
import java.util.Date;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UploadChatFile {
    private final FIleAssetRepository fileAssetRepository;

    private final S3Client s3Client;



    @Value("${r2.endpoint}")
    private String endpoint;


    public String uploadForMedia(MultipartFile file, Long senderId, Long receiverId) {
        try {
            // 1. 用 UUID 生成唯一文件名
            String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();

            // 2. 上传文件到cloud
            s3Client.putObject(
                    PutObjectRequest.builder()
                            .bucket("file-assets")  // 存储桶名称
                            .key(fileName)   // 文件在桶中的唯一标识
                            .contentType(file.getContentType()) // 文件类型（如 image/jpeg）
                            .build(),
                    RequestBody.fromInputStream(file.getInputStream(), file.getSize())
            );

            // 3. 生成CDN访问地址：作为文件公开访问的URL
            String cdnPublicPrefix = "https://pub-e5166f1c502b4ef1ac2ee1e0b450fcf2.r2.dev";
            String cdnUrl = cdnPublicPrefix + "/" + fileName;

            // 4. 构建元数据，保存到mongodb
            FileAsset fileAsset = new FileAsset();
            fileAsset.setSenderId(senderId);
            fileAsset.setReceiverId(receiverId);
            fileAsset.setFileName(fileName);
            fileAsset.setFileType(file.getContentType());
            fileAsset.setFileSize(file.getSize());
            fileAsset.setUrl(cdnUrl);                           // 文件访问URL
            fileAsset.setCreatedAt(new Date());  // 创建时间
            fileAsset.setCdnKey(fileName); // 保存 云储存文件的R2 key

            fileAssetRepository.save(fileAsset);

            return fileAsset.getUrl(); // 返回数据库记录的url
        } catch (IOException e) {
            throw new RuntimeException("上传失败：" + e.getMessage(), e);
        }
    }

}
