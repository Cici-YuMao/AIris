//package com.snl.media;
//
//import com.snl.media.service.UploadService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.mock.web.MockMultipartFile;
//import org.springframework.stereotype.Component;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.io.File;
//import java.io.FileInputStream;
//
//@Component
//public class BatchImageUploader implements CommandLineRunner {
//
//    @Autowired
//    private UploadService uploadService; // 替换为你实际的 service 类
//
//    @Override
//    public void run(String... args) throws Exception {
//        File folder = new File("/Users/snl/Documents/S/Project/图片/101-110"); // 替换为你的文件夹路径
//        File[] files = folder.listFiles();
//
//        if (files == null) {
//            System.out.println("文件夹为空或路径错误");
//            return;
//        }
//
//        for (File file : files) {
//            String fileName = file.getName();
//            if (!fileName.matches("\\d+\\.(jpg|png|jpeg)")) continue;
//
//            Long userId = Long.valueOf(fileName.split("\\.")[0]);
//            String contentType = fileName.endsWith(".png") ? "image/png" : "image/jpeg";
//
//            // 创建 MultipartFile
//            FileInputStream input = new FileInputStream(file);
//            MultipartFile multipartFile = new MockMultipartFile(
//                    fileName, fileName, contentType, input
//            );
//
//            // 调用你的上传方法
//            String mediaId = uploadService.uploadForMedia(multipartFile, userId);
//            System.out.println("上传成功，用户ID：" + userId + "，mediaId：" + mediaId);
//        }
//    }
//}
//
