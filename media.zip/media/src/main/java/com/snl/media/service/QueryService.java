package com.snl.media.service;

import com.snl.media.dao.MediaAssetRepository;
import com.snl.media.entity.MediaAsset;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class QueryService {

    private final MediaAssetRepository mediaRepo;

    public  MediaAsset getById(String id) {
        return mediaRepo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "未找到媒体资源，ID = " + id));
    }

    public List<MediaAsset> query(Long userId, String type, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        if (userId != null && type != null) {
            return mediaRepo.findByUserIdAndFileTypeContainingIgnoreCase(userId, type, pageable);
        } else if (userId != null) {
            return mediaRepo.findByUserId(userId, pageable);
        } else if (type != null) {
            return mediaRepo.findByFileTypeContainingIgnoreCase(type, pageable);
        } else {
            return mediaRepo.findAll(pageable).getContent();
        }
    }


    public Map<String, Object> getStats(Long userId) {
        Map<String, Object> stats = new HashMap<>();
        stats.put("total", mediaRepo.countByUserId(userId));
        stats.put("approved", mediaRepo.countByUserIdAndModerationStatus(userId, "APPROVED"));
        stats.put("pending", mediaRepo.countByUserIdAndModerationStatus(userId, "PENDING"));
        stats.put("rejected", mediaRepo.countByUserIdAndModerationStatus(userId, "REJECTED"));
        return stats;
    }



}

