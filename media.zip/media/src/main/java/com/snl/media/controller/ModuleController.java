package com.snl.media.controller;


// 对其他Module开放使用的接口

import com.snl.media.dao.MediaAssetRepository;
import com.snl.media.entity.ApiResponse;
import com.snl.media.entity.MediaAsset;
import com.snl.media.service.UploadChatFile;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
@Slf4j
@RestController // 请求处理类
@RequestMapping("/media")
@RequiredArgsConstructor
public class ModuleController {
    @Autowired
    private MediaAssetRepository mediaRepo;

    private final UploadChatFile uploadChatFile;

    // 获取用户可展示的图片
    @GetMapping("/public/images")
    public ResponseEntity<ApiResponse<?>> getPublicApprovedImages(@RequestParam(required = false) Long userId) {
        if (userId == null) {
            return ResponseEntity.badRequest().body(ApiResponse.error(400, "User ID is required"));
        }

        List<MediaAsset> assets = mediaRepo.findByUserIdAndIsPublicAndModerationStatus(userId, true, "APPROVED");

        if (assets.isEmpty()) {
            return ResponseEntity.ok(ApiResponse.emptyList("No public approved photo found"));
        }

        return ResponseEntity.ok(ApiResponse.success(assets));
    }
    // 储存聊天中的文件
    @PostMapping("/upload-chatFile")
    public ResponseEntity<ApiResponse<?>> uploadChatFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam("senderId") Long senderId,
            @RequestParam("receiverId") Long receiverId
    ) {
        if (file == null || file.isEmpty()) {
            return ResponseEntity.badRequest().body(ApiResponse.error(400, "File is required"));
        }
        if (senderId == null) {
            return ResponseEntity.badRequest().body(ApiResponse.error(400, "Sender ID is required"));
        }
        if (receiverId == null) {
            return ResponseEntity.badRequest().body(ApiResponse.error(400, "Receiver ID is required"));
        }

        String fileId = uploadChatFile.uploadForMedia(file, senderId, receiverId);
        return ResponseEntity.ok(ApiResponse.success(fileId));
    }

}
