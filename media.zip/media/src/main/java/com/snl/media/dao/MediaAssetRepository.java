package com.snl.media.dao;

import com.snl.media.entity.MediaAsset;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MediaAssetRepository extends MongoRepository<MediaAsset, String> {
    List<MediaAsset> findByUserId(Long userId, Pageable pageable);
    List<MediaAsset> findByFileTypeContainingIgnoreCase(String type, Pageable pageable);
    List<MediaAsset> findByUserIdAndFileTypeContainingIgnoreCase(Long userId, String type, Pageable pageable);

    List<MediaAsset> findByUserIdAndIsPublicAndModerationStatus(Long userId, boolean isPublic, String moderationStatus);



    long countByUserId(Long userId);
    long countByUserIdAndModerationStatus(Long userId, String status);

}
