package com.snl.media.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiResponse<T> {
    private int code;
    private String message;
    private T data;

    // 正常数据返回
    public static <T> ApiResponse<T> success(T data) {
        return new ApiResponse<>(200, "success", data);
    }

    // 空数组返回，仍使用 200 + 标准结构，message 不同
    public static <T> ApiResponse<List<T>> emptyList(String message) {
        return new ApiResponse<>(200, message, List.of());
    }

    // 错误返回
    public static <T> ApiResponse<T> error(int code, String message) {
        return new ApiResponse<>(code, message, null);
    }
}
