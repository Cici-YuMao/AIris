package com.snl.media.service;

import com.snl.media.R2Config;
import com.snl.media.dao.MediaAssetRepository;
import com.snl.media.entity.MediaAsset;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.S3Configuration;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;

import java.net.URI;

@Service
@RequiredArgsConstructor
public class DeleteService {

    private final MediaAssetRepository mediaRepo;
    private final R2Config r2Config;

    public void deleteById(String id) {

        // 1. 获取图片云端url
        MediaAsset asset = mediaRepo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "找不到媒体资源，ID = " + id));

        // 2. 删除云端图片
        if (asset.getCdnKey() != null && !asset.getCdnKey().isEmpty()) {
            try {
                S3Client s3Client = S3Client.builder()
                        .endpointOverride(URI.create(r2Config.getEndpoint()))
                        .credentialsProvider(StaticCredentialsProvider.create(
                                AwsBasicCredentials.create(r2Config.getAccessKey(), r2Config.getSecretKey())))
                        .region(Region.US_EAST_1)
                        .serviceConfiguration(S3Configuration.builder().pathStyleAccessEnabled(true).build())
                        .build();

                // 先检查是否存在这个对象
                s3Client.headObject(builder -> builder
                        .bucket(r2Config.getBucket())
                        .key(asset.getCdnKey())
                );

                // 如果没有抛异常，说明存在，可以删
                s3Client.deleteObject(DeleteObjectRequest.builder()
                        .bucket(r2Config.getBucket())
                        .key(asset.getCdnKey())
                        .build());

                System.out.println("CDN 文件删除成功：" + asset.getCdnKey());
            } catch (software.amazon.awssdk.services.s3.model.NoSuchKeyException e) {
                System.err.println("CDN 文件不存在：" + asset.getCdnKey());
            } catch (Exception e) {
                System.err.println("CDN 删除失败：" + e.getMessage());
            }
        }

        // 3. 删除数据库中图片相关元数据
        mediaRepo.deleteById(id);
        System.out.println("数据库记录删除成功：ID = " + id);
    }
}
