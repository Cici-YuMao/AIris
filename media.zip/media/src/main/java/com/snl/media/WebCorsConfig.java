//package com.snl.media;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.CorsRegistry;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//
//@Configuration
//public class WebCorsConfig {
//
//    @Bean
//    public WebMvcConfigurer corsConfigurer() {
//        return new WebMvcConfigurer() {
//            @Override
//            public void addCorsMappings(CorsRegistry registry) {
//                registry.addMapping("/**")  // 所有路径
//                        .allowedOrigins(
//                                "http://localhost:5173",
//                                "http://10.144.1.1:5173", // 远程IP
//                                "http://10.144.1.1:3000"
//                        )
//                        .allowedMethods("*")                     // 允许的 HTTP 方法
//                        .allowedHeaders("*")                     // 允许的请求头
//                        .allowCredentials(true);                 // 允许携带 Cookie
//            }
//        };
//    }
//}