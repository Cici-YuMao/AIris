package com.snl.media.service;

import com.snl.media.dao.MediaAssetRepository;
import com.snl.media.entity.MediaAsset;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AIModerationService {

    private final MediaAssetRepository mediaRepo;


    @Async
    public void reviewAsync(MediaAsset asset) {
        try {

            String mediaId = asset.getId();
            String imageUrl = asset.getUrl();
            Long userId = asset.getUserId();

            String apiUrl = "http://10.144.136.83:8080/api/review";

            // 构建请求体
            Map<String, String> requestBody = new HashMap<>();
            requestBody.put("media_id", mediaId);
            requestBody.put("image_url", imageUrl);
            System.out.println(requestBody);
            RestTemplate restTemplate = new RestTemplate();
            // 设置请求头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            // 发送POST请求
            System.out.println("开始连接算法部分");
            HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(requestBody, headers);
            ResponseEntity<Map> response = restTemplate.postForEntity(apiUrl, requestEntity, Map.class);
            System.out.println("已发送连接请求");

            // 处理响应
            if (response.getStatusCode().is2xxSuccessful()) {
                Map<String, Object> responseBody = response.getBody();
                String result = (String) responseBody.get("result"); // 返回字段名为"result"

                // 更新数据库状态
                asset.setModerationStatus(result);
                mediaRepo.save(asset);

                System.out.println( userId + "AI审核完成，结果：" + result);
            } else {
                System.err.println("AI审核请求失败，状态码：" + response.getStatusCode());
            }

        } catch (Exception e) {
            System.err.println("AI审核失败：" + e.getMessage());
            e.printStackTrace();
        }
    }








//    @Async
//    public void reviewAsync(MediaAsset asset) {
//        try {
//            // mock AI 审核逻辑（真实的可能几秒钟）
//            Thread.sleep(3000); // 模拟耗时
//            String result = "APPROVED"; // 或者根据图片内容生成
//
//            // 更新数据库状态
//            asset.setModerationStatus(result);
//            mediaRepo.save(asset);
//
//        } catch (Exception e) {
//            System.err.println("AI审核失败：" + e.getMessage());
//        }
//    }
}