package com.snl.media.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@Document("media_assets")
public class MediaAsset {
    @Id
    private String id;

    private Long userId;
    private String fileName;
    private String fileType;
    private Long fileSize;
    private String url;

    private String moderationStatus = "PENDING"; // PENDING / APPROVED / REJECTED
    private Date createdAt;
    private Date updatedAt;
    private String cdnKey;  // 上传到 CDN 的文件名（key）
    private Boolean isPublic = false; // 默认false，审核通过后可由用户设置

}
