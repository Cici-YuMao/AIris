package com.snl.media.service;

import com.snl.media.dao.MediaAssetRepository;
import com.snl.media.entity.MediaAsset;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.IOException;
import java.util.Date;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UploadService {

    private final MediaAssetRepository mediaRepo;
    private final S3Client s3Client;
    private  final AIModerationService aiModerationService;

    @Value("${r2.bucket}")
    private String bucket;

    @Value("${r2.endpoint}")
    private String endpoint;


    public String uploadForMedia(MultipartFile file, Long userId) {
        try {
            // 1. 用 UUID 生成唯一文件名
            String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();

            // 2. 上传文件到cloud
            s3Client.putObject(
                    PutObjectRequest.builder()
                            .bucket(bucket)  // 存储桶名称
                            .key(fileName)   // 文件在桶中的唯一标识
                            .contentType(file.getContentType()) // 文件类型（如 image/jpeg）
                            .build(),
                    RequestBody.fromInputStream(file.getInputStream(), file.getSize())
            );

            // 3. 生成CDN访问地址：作为文件公开访问的URL
            String cdnPublicPrefix = "https://pub-9224482d0b8e4f76bebd85f44e759ecb.r2.dev";
            String cdnUrl = cdnPublicPrefix + "/" + fileName;

            // 4. 构建元数据，保存到mongodb
            MediaAsset asset = new MediaAsset();
            asset.setUserId(userId);
            asset.setFileName(file.getOriginalFilename()); // 原始文件名
            asset.setFileType(file.getContentType());
            asset.setFileSize(file.getSize());
            asset.setUrl(cdnUrl);                           // 文件访问URL
            asset.setCreatedAt(new Date());  // 创建时间
            asset.setCdnKey(fileName); // 保存 云储存文件的R2 key
            mediaRepo.save(asset);

            // 5. 异步AI审核（不阻塞主线程）
            aiModerationService.reviewAsync(asset);

            return asset.getId(); // 返回数据库记录id
        } catch (IOException e) {
            throw new RuntimeException("上传失败：" + e.getMessage(), e);
        }
    }




}
