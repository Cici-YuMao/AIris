package com.snl.media.controller;

import com.snl.media.dao.MediaAssetRepository;
import com.snl.media.entity.MediaAsset;
import com.snl.media.service.DeleteService;
import com.snl.media.service.QueryService;
import com.snl.media.service.UploadService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController // 请求处理类
@RequestMapping("/media")
@RequiredArgsConstructor
public class ClientController {
    private final UploadService uploadService;
    private final MediaAssetRepository mediaAssetRepository;
    private final QueryService queryService;
    private final DeleteService deleteService;

    // 用户上传图片
    @PostMapping("/upload")
    public ResponseEntity<String> upload( @RequestParam("file") MultipartFile file,  @RequestParam("userId") Long userId){
        String id = uploadService.uploadForMedia(file, userId);
        // 返回的是media id
        return ResponseEntity.ok(id);
    }


    // 用户删除图片
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteById(@PathVariable String id) {
        deleteService.deleteById(id);
        return ResponseEntity.ok("Deleted media with ID: " + id);
    }

    // 切换图片可见状态
    @PutMapping("/{id}/visibility")
    public ResponseEntity<?> updateVisibility(
            @PathVariable String id,
            @RequestBody Map<String, Object> payload) {

        Boolean isPublic = (Boolean) payload.get("isPublic");
        if (isPublic == null) {
            return ResponseEntity.badRequest().body("Missing field: isPublic");
        }

        Optional<MediaAsset> optional = mediaAssetRepository.findById(id);
        if (optional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        MediaAsset media = optional.get();
        media.setIsPublic(isPublic);
        mediaAssetRepository.save(media);
        return ResponseEntity.ok(Map.of(
                "id", media.getId(),
                "isPublic", media.getIsPublic()
        ));
    }

    // 使用media id 查找 media asset元数据
    @GetMapping("/{id:[0-9a-f\\-]+}")
    public ResponseEntity<?> getById(@PathVariable String id) {
        MediaAsset asset = queryService.getById(id);
        return ResponseEntity.ok(asset);
    }

    @GetMapping
    public ResponseEntity<List<MediaAsset>> queryMedia(
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) String type,
            @RequestParam(required = false, defaultValue = "0") int page,
            @RequestParam(required = false, defaultValue = "10") int size
    ) {
        return ResponseEntity.ok(queryService.query(userId, type, page, size));
    }

    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getStats(@RequestParam Long userId) {
        return ResponseEntity.ok(queryService.getStats(userId));
    }

    // 轮询接口：获取指定媒体的审核状态
    @GetMapping("/{mediaId}/moderation")
    public ResponseEntity<?> getModerationStatus(@PathVariable String mediaId) {
        Optional<MediaAsset> optional = mediaAssetRepository.findById(mediaId);
        if (optional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        MediaAsset asset = optional.get();
        String status = asset.getModerationStatus(); //  APPROVED / REJECTED / PENDING
        System.out.println("mediaId: " + mediaId + " status: " + status);
        return ResponseEntity.ok().body(
                new ModerationResult(asset.getId(), status)
        );

    }

    // 定义返回格式
    record ModerationResult(String id, String moderationStatus) {}


}
