package com.snl.media.dao;

import com.snl.media.entity.FileAsset;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface FIleAssetRepository extends MongoRepository<FileAsset, String> {
}
